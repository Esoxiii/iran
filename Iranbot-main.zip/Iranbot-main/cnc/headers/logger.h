#ifndef LOGGER_H
#define LOGGER_H

void log_command(const char* user, const char* ip, const char* command);
void log_bot_join(const char* arch, const char* ip);
void log_bot_disconnected(const char* ip, const char* arch, const char* cause);
void log_anti_honeypot(const char* ip, const char* owner);
void log_invalid_arch(const char* ipbuf, const char* arch_reply);
#endif
