# Iranbot - Easiest source to setup
# Warning
- Please do not use this for infecting devices, it's illegal!, only use for research purposes.

# Requirements:
- Ubuntu 22, to 24
- Apache2 web server

# Summary of Features
- Comes with anti honeypot for linode & alibaba IPs
- Allows you to listen on shell for bots
- Sends shell commands
- 9 Different attack methods: UDP (raw), UDPPLAIN, SYN, TCP (handshake), HTTP, ICMP, GREIP, GRETCP, GREUDP
- Aggressive killer that obliterates competiting malware
- Easy to setup!
- Self update capability
- Comes with easter eggs (Oh no, cnc is dead... it's over..)
- Comes with watchdog feeder
- Children can respawn parent proc when it dies (e.g SIGSEGV, SIGILL), letting main proc to reconnect to cnc back, which is rare (most sources dont do this for some reason)

# Negatives of the source:
- Designed to hold up to 1000-2000 bots only, more will be unstable
- Made for Telnet, routers, android & other unstable
- No Custom domain resolve support, relies on device /etc/resolv.conf
